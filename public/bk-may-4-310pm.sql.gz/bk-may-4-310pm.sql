-- MariaDB dump 10.19  Distrib 10.11.11-MariaDB, for debian-linux-gnu (aarch64)
--
-- Host: localhost    Database: db
-- ------------------------------------------------------
-- Server version	10.11.11-MariaDB-ubu2204-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `applications`
--

DROP TABLE IF EXISTS `applications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `applications` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `location_id` bigint(20) unsigned NOT NULL,
  `meeting_id` bigint(20) unsigned NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `slug` varchar(255) NOT NULL,
  `file_number` varchar(255) DEFAULT NULL,
  `application_number` varchar(255) DEFAULT NULL,
  `related_application` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `url` text DEFAULT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `applications_location_id_foreign` (`location_id`),
  KEY `applications_meeting_id_foreign` (`meeting_id`),
  KEY `applications_user_id_foreign` (`user_id`),
  CONSTRAINT `applications_location_id_foreign` FOREIGN KEY (`location_id`) REFERENCES `locations` (`id`) ON DELETE CASCADE,
  CONSTRAINT `applications_meeting_id_foreign` FOREIGN KEY (`meeting_id`) REFERENCES `meetings` (`id`) ON DELETE CASCADE,
  CONSTRAINT `applications_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `applications`
--

LOCK TABLES `applications` WRITE;
/*!40000 ALTER TABLE `applications` DISABLE KEYS */;
/*!40000 ALTER TABLE `applications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache`
--

DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache` (
  `key` varchar(255) NOT NULL,
  `value` mediumtext NOT NULL,
  `expiration` int(11) NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache`
--

LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_locks`
--

DROP TABLE IF EXISTS `cache_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_locks` (
  `key` varchar(255) NOT NULL,
  `owner` varchar(255) NOT NULL,
  `expiration` int(11) NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_locks`
--

LOCK TABLES `cache_locks` WRITE;
/*!40000 ALTER TABLE `cache_locks` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_locks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_batches`
--

DROP TABLE IF EXISTS `job_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `job_batches` (
  `id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `total_jobs` int(11) NOT NULL,
  `pending_jobs` int(11) NOT NULL,
  `failed_jobs` int(11) NOT NULL,
  `failed_job_ids` longtext NOT NULL,
  `options` mediumtext DEFAULT NULL,
  `cancelled_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `finished_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_batches`
--

LOCK TABLES `job_batches` WRITE;
/*!40000 ALTER TABLE `job_batches` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_batches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) NOT NULL,
  `payload` longtext NOT NULL,
  `attempts` tinyint(3) unsigned NOT NULL,
  `reserved_at` int(10) unsigned DEFAULT NULL,
  `available_at` int(10) unsigned NOT NULL,
  `created_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `location_video_segments`
--

DROP TABLE IF EXISTS `location_video_segments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `location_video_segments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `video_id` bigint(20) unsigned NOT NULL,
  `location_id` bigint(20) unsigned NOT NULL,
  `video_start` bigint(20) NOT NULL,
  `transcript` text NOT NULL,
  `ai_summary` text NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `location_video_segments_video_id_foreign` (`video_id`),
  KEY `location_video_segments_location_id_foreign` (`location_id`),
  KEY `location_video_segments_user_id_foreign` (`user_id`),
  CONSTRAINT `location_video_segments_location_id_foreign` FOREIGN KEY (`location_id`) REFERENCES `locations` (`id`) ON DELETE CASCADE,
  CONSTRAINT `location_video_segments_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `location_video_segments_video_id_foreign` FOREIGN KEY (`video_id`) REFERENCES `meeting_videos` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `location_video_segments`
--

LOCK TABLES `location_video_segments` WRITE;
/*!40000 ALTER TABLE `location_video_segments` DISABLE KEYS */;
/*!40000 ALTER TABLE `location_video_segments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `locations`
--

DROP TABLE IF EXISTS `locations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `locations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `location` varchar(255) NOT NULL,
  `old_address` varchar(255) DEFAULT NULL,
  `slug` varchar(255) NOT NULL,
  `postal_code` varchar(255) DEFAULT NULL,
  `province` text NOT NULL,
  `ward` text DEFAULT NULL,
  `lat` double DEFAULT NULL,
  `long` double DEFAULT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `locations_user_id_foreign` (`user_id`),
  KEY `locations_updated_by_foreign` (`updated_by`),
  CONSTRAINT `locations_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `locations_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=378 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `locations`
--

LOCK TABLES `locations` WRITE;
/*!40000 ALTER TABLE `locations` DISABLE KEYS */;
INSERT INTO `locations` VALUES
(1,'20 Tom Wells Crescent','20 Tom Wells Crescent','20-tom-wells-crescent','M1V 2Y6','ON','Scarborough-Agincourt\n(22)',43.8175746,-79.3122875,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:45:59'),
(2,'365 Rouge Hills Drive','365 Rouge Hills Drive','365-rouge-hills-drive','M1C 2X8','ON','Scarborough-Rouge Park\n(25)',43.7946386,-79.1301207,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:46:01'),
(3,'17 Sundridge Drive','17 Sundridge Drive','17-sundridge-drive','M1L 2K1','ON','Scarborough Southwest\n(20)',43.7213723,-79.2977585,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:46:02'),
(5,'6 Sheldonbury Crescent','6 Sheldonbury Crescent','6-sheldonbury-crescent','M1W 1L7','ON','Scarborough-Agincourt\n(22)',43.7867048,-79.3187983,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:46:05'),
(6,'37 Porter Crescent','37 Porter Crescent','37-porter-crescent','M1P 2P7','ON','Scarborough Centre (21)',43.7454254,-79.2765307,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:46:07'),
(7,'79 Elinor Avenue','79 Elinor Avenue','79-elinor-avenue','M1R 3J6','ON','Scarborough Centre (21)',43.7495178,-79.3025926,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:46:08'),
(8,'2075 McNicoll Avenue','2075 McNicoll Avenue','2075-mcnicoll-avenue','M1W 3W6','ON','Scarborough-Agincourt\n(22)',43.803876,-79.3320808,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:46:10'),
(9,'80 Dale Avenue','80 Dale Avenue','80-dale-avenue','M4W 1K2','ON','Scarborough-Guildwood\n(24)',43.6751883,-79.3689408,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:46:11'),
(10,'1111 Kingston Road','1111 Kingston Road','1111-kingston-road','L1V 2W8','ON','Scarborough Southwest\n(20)',43.8291752,-79.0983502,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:46:13'),
(11,'109 Magnolia Avenue','109 Magnolia Avenue','109-magnolia-avenue','M1K 3L4','ON','Scarborough Southwest\n(20)',43.7238039,-79.2559639,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:46:15'),
(12,'107 Magnolia Avenue','107 Magnolia Avenue','107-magnolia-avenue','E4E 2H2','ON','Scarborough Southwest\n(20)',45.7191424,-65.5059258,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:46:17'),
(13,'15 Knockbolt Crescent','15 Knockbolt Crescent','15-knockbolt-crescent','M1S 4T0','ON','Scarborough North (23)',43.8028487,-79.2835211,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:46:18'),
(14,'46 North Bonnington Avenue','46 North Bonnington Avenue','46-north-bonnington-avenue','M1K 1A8','ON','Scarborough Southwest\n(20)',43.7090168,-79.2628606,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:46:20'),
(15,'11 Crescentwood Road','11 Crescentwood Road','11-crescentwood-road','M1N 1S2','ON','Scarborough Southwest\n(20)',43.6847188,-79.2684452,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:46:21'),
(16,'9 Crescentwood Road','9 Crescentwood Road','9-crescentwood-road','M1N 2V8','ON','Scarborough Southwest\n(20)',43.6846345,-79.2685159,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:46:23'),
(17,'24 Rossander Court','24 Rossander Court','24-rossander-court','M1J 1J0','ON','Scarborough Centre (21)',43.7520593,-79.241733,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:46:24'),
(18,'43 Harmony Avenue','43 Harmony Avenue','43-harmony-avenue','M1K 1G5','ON','Scarborough Southwest\n(20)',43.7208189,-79.2536917,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:46:26'),
(19,'11 Florens Avenue','11 Florens Avenue','11-florens-avenue','M1L 3H1','ON','Scarborough Southwest\n(20)',43.7043366,-79.2882865,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:46:27'),
(21,'1891 Eglinton Avenue East','1891 Eglinton Avenue East','1891-eglinton-avenue-east','M1L 2L1','ON','Scarborough Southwest\n(20)',43.7254816,-79.29725,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:46:30'),
(22,'32 Aylesworth Avenue','32 Aylesworth Avenue','32-aylesworth-avenue','L1E 3J2','ON','Scarborough Southwest\n(20)',43.888051,-78.8004911,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:46:32'),
(23,'72 Bexhill Avenue','72 Bexhill Avenue','72-bexhill-avenue','M1L 3H1','ON','Scarborough Southwest\n(20)',43.7041993,-79.2897243,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:46:33'),
(24,'3650 Danforth Avenue','3650 Danforth Avenue','3650-danforth-avenue','K1Z 5C6','ON','Scarborough Southwest\n(20)',45.3914671,-75.7535698,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:46:35'),
(25,'56 Galloway Road','56 Galloway Road','56-galloway-road','M1E 1S4','ON','Scarborough-Guildwood\n(24)',43.7540078,-79.1914565,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:46:37'),
(26,'3370 Brimley Road','3370 Brimley Road','3370-brimley-road','M1V 2J7','ON','Scarborough North (23)',43.8251416,-79.2863091,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:46:38'),
(27,'109 Prairie Drive','109 Prairie Drive','109-prairie-drive','M1L 3Z3','ON','Scarborough Southwest\n(20)',43.6986748,-79.2794647,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:46:40'),
(28,'5951 Steeles Avenue East','5951 Steeles Avenue East','5951-steeles-avenue-east','L3S 3B8','ON','Scarborough North (23)',43.8351225,-79.2569673,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:46:41'),
(29,'41 Roseglor Crescent','41 Roseglor Crescent','41-roseglor-crescent','M1P 2S7','ON','Scarborough Centre (21)',43.7553022,-79.256945,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:46:43'),
(30,'56 Falmouth Avenue','56 Falmouth Avenue','56-falmouth-avenue','M1K 4M7','ON','Scarborough Southwest\n(20)',43.733528,-79.2523908,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:46:44'),
(31,'262 Centennial Road','262 Centennial Road','262-centennial-road','M1C 1Z9','ON','Scarborough-Rouge Park\n(25)',43.7867422,-79.1506112,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:46:46'),
(32,'8 Kerwood Crescent','8 Kerwood Crescent','8-kerwood-crescent','M1T 2T6','ON','Scarborough-Agincourt\n(22)',43.7775134,-79.290499,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:46:47'),
(33,'2 Willowhurst Crescent','2 Willowhurst Crescent','2-willowhurst-crescent','M1R 3V8','ON','Scarborough Centre (21)',43.7549747,-79.2968676,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:46:49'),
(34,'4 Fieldside Drive','4 Fieldside Drive','4-fieldside-drive','M1V 1P6','ON','Scarborough North (23)',43.8159278,-79.2652355,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:46:50'),
(35,'91 Craiglee Drive','91 Craiglee Drive','91-craiglee-drive','M1N 2M7','ON','Scarborough Southwest\n(20)',43.7063611,-79.2538321,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:46:51'),
(36,'91 Eastville Avenue','91 Eastville Avenue','91-eastville-avenue','M1M 1N3','ON','Scarborough Southwest\n(20)',43.7181364,-79.2354259,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:46:53'),
(37,'43 McIntosh Street','43 McIntosh Street','43-mcintosh-street','M1N 1T6','ON','Scarborough Southwest\n(20)',43.7042031,-79.2540163,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:46:54'),
(38,'49 Bobmar Road','49 Bobmar Road','49-bobmar-road','M1C 1A8','ON','Scarborough-Rouge Park\n(25)',43.7853849,-79.1782943,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:46:56'),
(39,'46 Fallingbrook Drive','46 Fallingbrook Drive','46-fallingbrook-drive','L3C 1Y5','ON','Scarborough Southwest\n(20)',43.027443,-79.2862848,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:46:57'),
(40,'3 Kingsbury Crescent','3 Kingsbury Crescent','3-kingsbury-crescent','T8N 3R3','ON','Scarborough Southwest\n(20)',53.6522244,-113.5883499,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:46:59'),
(41,'16 Pelmar Place','16 Pelmar Place','16-pelmar-place','M1G 1G8','ON','Scarborough Guildwood\n(24)',43.756808,-79.2163322,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:47:00'),
(42,'261 Bellamy Road North','261 Bellamy Road North','261-bellamy-road-north','M1J 2V6','ON','Scarborough Guildwood\n(24)',43.750407,-79.2324905,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:47:02'),
(44,'128 Ridgewood Road','128 Ridgewood Road','128-ridgewood-road','M1C 4M5','ON','Scarborough- Rouge Park\n(25)',43.7863268,-79.1275749,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:47:05'),
(45,'66 Glen Watford Drive','66 Glen Watford Drive','66-glen-watford-drive','M1S 1R6','ON','Scarborough North (23)',43.7924395,-79.2796939,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:47:06'),
(46,'137 Sandown Avenue','137 Sandown Avenue','137-sandown-avenue','M1N 4A7','ON','Scarborough Southwest\n(20)',43.7157991,-79.2537511,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:47:08'),
(47,'44 Bonnechere Crescent','44 Bonnechere Crescent','44-bonnechere-crescent','M1J 1C2','ON','Scarborough Centre (21)',43.7456545,-79.2549193,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:47:09'),
(48,'2008 Pharmacy Avenue','2008 Pharmacy Avenue','2008-pharmacy-avenue','M1T 1P7','ON','Scarborough-Agincourt\n(22)',43.7767043,-79.3191665,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:47:10'),
(49,'31 Gilder Drive','31 Gilder Drive','31-gilder-drive','M1K 2R5','ON','Scarborough Centre (21)',43.736067,-79.2562363,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:47:12'),
(50,'41 Pine Ridge Drive','41 Pine Ridge Drive','41-pine-ridge-drive','M1M 3N8','ON','Scarborough Southwest\n(20)',43.7284806,-79.2237335,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:47:13'),
(51,'430 Guildwood Parkway','430 Guildwood Parkway','430-guildwood-parkway','M1E 1R3','ON','Scarborough-Guildwood\n(24)',43.7510708,-79.1838063,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:47:15'),
(52,'25 Queensbury Avenue','25 Queensbury Avenue','25-queensbury-avenue','M1N 2V8','ON','Scarborough Southwest\n(20)',43.686472,-79.2747011,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:47:16'),
(53,'94 Kitchener Road','94 Kitchener Road','94-kitchener-road','M1E 1Z7','ON','Scarborough Guildwood\n(24)',43.7613034,-79.1875888,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:47:18'),
(54,'18 Leahann Drive','18 Leahann Drive','18-leahann-drive','M1P 1C8','ON','Scarborough Centre (21)',43.7432457,-79.2805329,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:47:19'),
(55,'9 Linden Avenue','9 Linden Avenue','9-linden-avenue','N3S 3T4','ON','Scarborough Southwest\n(20)',43.1446512,-80.2174406,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:47:21'),
(56,'192 Tower Drive','192 Tower Drive','192-tower-drive','M1R 3V3','ON','Scarborough Centre (21)',43.7541023,-79.3001199,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:47:22'),
(57,'27 Milliken Boulevard','27 Milliken Boulevard','27-milliken-boulevard','M1V 1S9','ON','Scarborough Agincourt\n(22)',43.8045237,-79.2953515,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:47:24'),
(58,'22 Hart Avenue','22 Hart Avenue','22-hart-avenue','M1K 3G5','ON','Scarborough Southwest\n(20)',43.7202269,-79.2597677,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:47:25'),
(59,'33 Reidmount Avenue','33 Reidmount Avenue','33-reidmount-avenue','M1T 3T8','ON','Scarborough Agincourt\n(22)',43.7864867,-79.2856329,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:47:27'),
(60,'22 Westcroft Drive','22 Westcroft Drive','22-westcroft-drive','M1E 1X5','ON','Scarborough Guildwood\n(24)',43.7696537,-79.1929838,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:47:28'),
(61,'253 Markham Road','253 Markham Road','253-markham-road','M1J 3C3','ON','Scarborough Guildwood\n(24)',43.7467413,-79.2202121,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:47:30'),
(62,'6 Sheva Court','6 Sheva Court','6-sheva-court','M1K 4C9','ON','Scarborough Southwest\n(20)',43.7290224,-79.2595594,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:47:31'),
(63,'22 Burnley Avenue','22 Burnley Avenue','22-burnley-avenue','M1R 2Y7','ON','Scarborough Centre (21)',43.7434164,-79.3089984,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:47:33'),
(64,'167 Brycemoor Road','167 Brycemoor Road','167-brycemoor-road','M1C 2X8','ON','Scarborough- Rouge Park\n(25)',43.7979495,-79.1347442,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:47:34'),
(65,'64 Glen Watford Drive','64 Glen Watford Drive','64-glen-watford-drive','M1S 1R6','ON','Scarborough North (23)',43.792177,-79.2795786,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:47:36'),
(66,'3089 Danforth Avenue','3089 Danforth Avenue','3089-danforth-avenue','M1L 1B3','ON','Scarborough Southwest\n(20)',43.6914282,-79.2868064,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:47:37'),
(67,'3850 Finch Avenue East','3850 Finch Avenue East','3850-finch-avenue-east','M1T 3C6','ON','Scarborough-Agincourt\n(22)',43.8003408,-79.3009003,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:47:39'),
(68,'4694 Kingston Road','4694 Kingston Road','4694-kingston-road','M1E 2P9','ON','Scarborough- Rouge Park\n(25)',43.7778225,-79.1728141,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:47:40'),
(69,'1 Haig Avenue','1 Haig Avenue','1-haig-avenue','M1N 1V2','ON','Scarborough Southwest\n(20)',43.685736,-79.2710485,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:47:42'),
(70,'36 Cliffcrest Drive','36 Cliffcrest Drive','36-cliffcrest-drive','M1M 2K8','ON','Scarborough Southwest\n(20)',43.7077739,-79.2439506,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:47:43'),
(71,'1207 Warden Avenue','1207 Warden Avenue','1207-warden-avenue','M1R 2Z3','ON','Scarborough Centre (21)',43.7484561,-79.2958136,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:47:45'),
(72,'1160 Birchmount Road','1160 Birchmount Road','1160-birchmount-road','M1P 1C8','ON','Scarborough Centre (21)',43.741433,-79.2825558,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:47:46'),
(73,'4466 Sheppard Avenue East','4466 Sheppard Avenue East','4466-sheppard-avenue-east','M1S 1V2','ON','Scarborough North (23)',43.7884237,-79.2665722,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:47:48'),
(74,'1420 Kingston Road','1420 Kingston Road','1420-kingston-road','M1N 2V8','ON','Scarborough Southwest\n(20)',43.6871805,-79.2720652,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:47:50'),
(75,'57 Neilson Avenue','57 Neilson Avenue','57-neilson-avenue','M1M 1N3','ON','Scarborough Southwest\n(20)',43.7206375,-79.2325155,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:47:51'),
(76,'23 David Drive','23 David Drive','23-david-drive','K2G 2P3','ON','Scarborough-Guildwood\n(24)',45.3507455,-75.739043,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:47:53'),
(77,'32 Crescentwood Road','32 Crescentwood Road','32-crescentwood-road','M1N 1S2','ON','Scarborough Southwest\n(20)',43.6859498,-79.2671342,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:47:54'),
(78,'18 Abbottswood Road','18 Abbottswood Road','18-abbottswood-road','M1P 3S4','ON','Scarborough Centre (21)',43.7660567,-79.2678731,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:47:55'),
(79,'145 Phyllis Avenue','145 Phyllis Avenue','145-phyllis-avenue','M1M 0E1','ON','Scarborough Southwest\n(20)',43.7297156,-79.2341133,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:47:57'),
(80,'6 Gilroy Drive','6 Gilroy Drive','6-gilroy-drive','M1P 4V6','ON','Scarborough Centre (21)',43.7582117,-79.2800806,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:47:58'),
(81,'59 Fenwood Heights','59 Fenwood Heights','59-fenwood-heights','M1M 2T6','ON','Scarborough Southwest\n(20)',43.7252365,-79.2276098,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:48:00'),
(82,'24 Hagley Road','24 Hagley Road','24-hagley-road','M1N 4A7','ON','Scarborough Southwest\n(20)',43.7164164,-79.2480929,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:48:01'),
(83,'78 Parade Square','78 Parade Square','78-parade-square','M1C 3T7','ON','Scarborough-Rouge Park\n(25)',43.7923681,-79.1815586,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:48:03'),
(84,'1 Nantucket Boulevard','1 Nantucket Boulevard','1-nantucket-boulevard','M1P 4X1','ON','Scarborough Centre (21)',43.7518208,-79.2718311,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:48:04'),
(85,'897 Victoria Park Avenue','897 Victoria Park Avenue','897-victoria-park-avenue','M4B 2E6','ON','Scarborough Southwest\n(20)',43.700607,-79.2922312,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:48:06'),
(86,'60 Phillip Avenue','60 Phillip Avenue','60-phillip-avenue','M1N 2M7','ON','Scarborough Southwest\n(20)',43.7062062,-79.2561172,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:48:07'),
(87,'119 Heale Avenue','119 Heale Avenue','119-heale-avenue','M1N 4A7','ON','Scarborough Southwest\n(20)',43.7156507,-79.2512034,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:48:09'),
(88,'2463 Kennedy Road','2463 Kennedy Road','2463-kennedy-road','M1S 1H5','ON','Scarborough-Agincourt\n(22)',43.7889213,-79.2905991,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:48:10'),
(89,'11 West Hill Drive','11 West Hill Drive','11-west-hill-drive','M5E 3E6','ON','Scarborough-Rouge Park\n(25)',43.7714933,-79.1804659,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:48:12'),
(90,'38 Clonmore Drive','38 Clonmore Drive','38-clonmore-drive','M1N 2V8','ON','Scarborough Southwest\n(20)',43.6852105,-79.280208,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:48:14'),
(91,'545 Danforth Road','545 Danforth Road','545-danforth-road','M1K 1W3','ON','Scarborough Southwest\n(20)',43.7098446,-79.2651233,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:48:15'),
(92,'20 Martindale Road','20 Martindale Road','20-martindale-road','M1M 1Z3','ON','Scarborough Southwest\n(20)',43.7333615,-79.2335464,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:48:17'),
(93,'512 Rouge Hills Drive','512 Rouge Hills Drive','512-rouge-hills-drive','M1C 2X8','ON','Scarborough-Rouge Park\n(25)',43.7999987,-79.1331941,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:48:19'),
(94,'4100 Lawrence Avenue East','4100 Lawrence Avenue East','4100-lawrence-avenue-east','M1E 2S2','ON','Scarborough-Guildwood\n(24)',43.767014,-79.1954254,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:48:20'),
(95,'31 Marchington Circle','31 Marchington Circle','31-marchington-circle','M1R 4B0','ON','Scarborough Centre (21)',43.7586311,-79.307783,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:48:21'),
(96,'24 Winter Avenue','24 Winter Avenue','24-winter-avenue','A1B 2L5','ON','Scarborough Southwest\n(20)',47.5767991,-52.7067024,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:48:23'),
(98,'164 Warden Avenue','164 Warden Avenue','164-warden-avenue','M1N 2V8','ON','Scarborough Southwest\n(20)',43.6868732,-79.2706768,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:48:26'),
(99,'345 Midwest Road','345 Midwest Road','345-midwest-road','M1P 2N9','ON','Scarborough Centre (21)',43.7622591,-79.2716492,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:48:27'),
(100,'76 Clonmore Drive','76 Clonmore Drive','76-clonmore-drive','M1N 2V8','ON','Scarborough Southwest\n(20)',43.6878782,-79.2786394,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:48:29'),
(101,'2971 Sheppard Avenue East','2971 Sheppard Avenue East','2971-sheppard-avenue-east','M1T 3J4','ON','Scarborough-Agincourt\n(22)',43.7758583,-79.3198907,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:48:30'),
(102,'2540 Gerrard Street East','2540 Gerrard Street East','2540-gerrard-street-east','M4E 2E1','ON','Scarborough Southwest\n(20)',43.6855641,-79.2928207,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:48:32'),
(103,'22 Eastville Avenue','22 Eastville Avenue','22-eastville-avenue','M1M 1C7','ON','Scarborough Southwest\n(20)',43.7137294,-79.2338268,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:48:34'),
(104,'448 Markham Road','448 Markham Road','448-markham-road','M1H 3A1','ON','Scarborough Guildwood\n(24)',43.7511123,-79.2224777,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:48:35'),
(105,'25 Scarborough Golf Club Road','25 Scarborough Golf Club Road','25-scarborough-golf-club-road','M1M 3B1','ON','Scarborough Guildwood\n(24)',43.7447413,-79.2086176,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:48:37'),
(106,'1275 Morningside Avenue','1275 Morningside Avenue','1275-morningside-avenue','M1B 3E8','ON','Scarborough- Rouge Park\n(25)',43.8028078,-79.1998845,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:48:38'),
(107,'12 Woodland Park Road','12 Woodland Park Road','12-woodland-park-road','N0H 2P0','ON','Scarborough Southwest\n(20)',44.5432535,-80.4160418,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:48:41'),
(108,'198 Tower Drive','198 Tower Drive','198-tower-drive','M1R 3V3','ON','Scarborough Centre (21)',43.7541918,-79.2996768,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:48:43'),
(109,'73 Griffen Drive','73 Griffen Drive','73-griffen-drive','M1B 1B3','ON','Scarborough North (23)',43.7988566,-79.2242907,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:48:44'),
(110,'2181 Mcnicoll Avenue','2181 Mcnicoll Avenue','2181-mcnicoll-avenue','M1V 5P1','ON','Scarborough-Agincourt\n(22)',43.8137867,-79.2949497,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:48:45'),
(111,'84 Cliffcrest Drive','84 Cliffcrest Drive','84-cliffcrest-drive','M1M 2K8','ON','Scarborough Southwest\n(20)',43.7108964,-79.2446578,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:48:47'),
(112,'96 Cedar Brae Boulevard','96 Cedar Brae Boulevard','96-cedar-brae-boulevard','M1J 2M7','ON','Scarborough Centre (21)',43.7519038,-79.2359403,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:48:48'),
(113,'52 Bellamy Road South','52 Bellamy Road South','52-bellamy-road-south','M1M 3R2','ON','Scarborough Southwest\n(20)',43.7364478,-79.2266202,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:48:50'),
(114,'73 North Woodrow Boulevard','73 North Woodrow Boulevard','73-north-woodrow-boulevard','M1K 1W3','ON','Scarborough Southwest\n(20)',43.7118075,-79.2650164,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:48:51'),
(115,'3325 Ellesmere Road','3325 Ellesmere Road','3325-ellesmere-road','M1C 1H1','ON','Scarborough- Rouge Park\n(25)',43.7870501,-79.1854489,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:48:53'),
(116,'70 Hollis Avenue','70 Hollis Avenue','70-hollis-avenue','M1N 1S2','ON','Scarborough Southwest\n(20)',43.6939394,-79.2686112,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:48:54'),
(117,'33 Huntsmill Boulevard','33 Huntsmill Boulevard','33-huntsmill-boulevard','M1W 3R3','ON','Scarborough-Agincourt\n(22)',43.8103679,-79.3261781,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:48:56'),
(118,'263 Ellington Drive','263 Ellington Drive','263-ellington-drive','M1R 2S3','ON','Scarborough Centre (21)',43.7573451,-79.2990038,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:48:57'),
(120,'62 Seminole Avenue','62 Seminole Avenue','62-seminole-avenue','M1J 1M8','ON','Scarborough Centre (21)',43.7468874,-79.2475326,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:49:00'),
(121,'89 Claremore Avenue','89 Claremore Avenue','89-claremore-avenue','M1N 2M7','ON','Scarborough Southwest\n(20)',43.7091983,-79.2559192,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:49:01'),
(122,'7437 Kingston Road','7437 Kingston Road','7437-kingston-road','M4E 1R7','ON','Scarborough- Rouge Park\n(25)',43.6791159,-79.2971584,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:49:03'),
(123,'7431 Kingston Road','7431 Kingston Road','7431-kingston-road','M1C 2P5','ON','Scarborough- Rouge Park\n(25)',43.8002705,-79.1433715,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:49:05'),
(124,'46 Glen Muir Drive','46 Glen Muir Drive','46-glen-muir-drive','M1M 3R2','ON','Scarborough Southwest\n(20)',43.736693,-79.2279114,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:49:07'),
(125,'3992 Ellesmere Road','3992 Ellesmere Road','3992-ellesmere-road','M1C 0C3','ON','Scarborough- Rouge Park\n(25)',43.7930526,-79.162205,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:49:09'),
(126,'52 Brumwell Street','52 Brumwell Street','52-brumwell-street','M1C 2A2','ON','Scarborough- Rouge Park\n(25)',43.7914925,-79.1489792,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:49:10'),
(127,'44 Rolark Drive','44 Rolark Drive','44-rolark-drive','M1W 2H5','ON','Scarborough Centre (21)',43.7654633,-79.294934,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:49:11'),
(128,'38 Dennett Drive','38 Dennett Drive','38-dennett-drive','M1S 2E2','ON','Scarborough North (23)',43.7913433,-79.2748989,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:49:13'),
(129,'22 Kootenay Crescent','22 Kootenay Crescent','22-kootenay-crescent','R2C 5R6','ON','Scarborough Centre (21)',49.8989988,-97.023334,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:49:14'),
(130,'27 Mansion Avenue','27 Mansion Avenue','27-mansion-avenue','M1L 3E4','ON','Scarborough Southwest\n(20)',43.6911404,-79.2815811,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:49:16'),
(131,'271 Victoria Park Avenue','271 Victoria Park Avenue','271-victoria-park-avenue','M1N 2S4','ON','Scarborough Southwest\n(20)',43.683196,-79.284847,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:49:18'),
(132,'1061 Markham Road','1061 Markham Road, Unit 904 (No Meadowglen Place, no unit B, C & D included)','1061-markham-road-unit-904-no-meadowglen-place-no-unit-b-c-d-included','M1H 3B7','ON','Scarborough Guildwood\n(24)',43.774449,-79.2308514,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:49:19'),
(133,'25 Lynndale Road','25 Lynndale Road','25-lynndale-road','N3Y 5G7','ON','Scarborough Southwest\n(20)',42.8414555,-80.2955933,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:49:20'),
(134,'449 Lawson Road','449 Lawson Road','449-lawson-road','M1C 2L0','ON','Scarborough- Rouge Park\n(25)',43.7894863,-79.1410875,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:49:22'),
(136,'54 Bondgate Court','54 Bondgate Court','54-bondgate-court','M1B 1Y3','ON','Scarborough North (23)',43.8116135,-79.2287235,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:49:26'),
(137,'59 Aragon Avenue','59 Aragon Avenue','59-aragon-avenue','M1T 3K7','ON','Scarborough Agincourt\n(22)',43.7769882,-79.3032396,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:49:27'),
(138,'139 Bexhill Avenue','139 Bexhill Avenue','139-bexhill-avenue','M1L 3H1','ON','Scarborough Southwest\n(20)',43.7086115,-79.2913633,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:49:29'),
(139,'29 Anson Avenue','29 Anson Avenue','29-anson-avenue','M1M 1V3','ON','Scarborough Southwest\n(20)',43.7251861,-79.2389191,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:49:30'),
(140,'72 Heale Avenue','72 Heale Avenue','72-heale-avenue','M1N 4A7','ON','Scarborough Agincourt\n(22)',43.7136099,-79.2506048,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:49:32'),
(141,'35 Benroyal Crescent','35 Benroyal Crescent','35-benroyal-crescent','M1H 1M4','ON','Scarborough-Guildwood\n(24)',43.7598443,-79.2434562,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:49:33'),
(142,'5 Balcarra Avenue','5 Balcarra Avenue','5-balcarra-avenue','M1M 1P2','ON','Scarborough Southwest\n(20)',43.726066,-79.2268957,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:49:35'),
(143,'46 Pitt Avenue','46 Pitt Avenue','46-pitt-avenue','M1L 1T4','ON','Scarborough Southwest\n(20)',43.7020161,-79.2920639,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:49:36'),
(144,'756 Warden Avenue','756 Warden Avenue','756-warden-avenue','K1E 1T4','ON','Scarborough Southwest\n(20)',45.471845,-75.5015671,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:49:38'),
(146,'3465 Kingston Road','3465 Kingston Road','3465-kingston-road','M1M 2Z8','ON','Scarborough Southwest\n(20)',43.7376152,-79.2179599,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:49:41'),
(147,'12 Phillip Avenue','12 Phillip Avenue','12-phillip-avenue','M1N 1T6','ON','Scarborough Southwest\n(20)',43.7038123,-79.2551278,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:49:43'),
(148,'161 Magnolia Avenue','161 Magnolia Avenue','161-magnolia-avenue','M1K 3L4','ON','Scarborough Southwest\n(20)',43.7259534,-79.2568917,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:49:45'),
(149,'2301 Brimley Road','2301 Brimley Road','2301-brimley-road','M1S 5B8','ON','Scarborough North (23)',43.797754,-79.2707794,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:49:46'),
(150,'356 Morrish Road','356 Morrish Road','356-morrish-road','M1C 4Y1','ON','Scarborough-Rouge Park\n(25)',43.7877466,-79.1726756,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:49:48'),
(151,'59 Regency Square','59 Regency Square','59-regency-square','M1E 1L8','ON','Scarborough-Guildwood\n(24)',43.7517927,-79.195926,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:49:49'),
(152,'50A Atlee Avenue','50A Atlee Avenue','50a-atlee-avenue','M1N 4A7','ON','Scarborough Southwest\n(20)',43.7140443,-79.2519118,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:49:51'),
(153,'1 Trefoil Court','1 Trefoil Court','1-trefoil-court','M1X 0A3','ON','Scarborough North (23)',43.8311778,-79.2291468,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:49:52'),
(154,'34 Hunt Club Drive','34 Hunt Club Drive','34-hunt-club-drive','M1N 2V8','ON','Scarborough Southwest\n(20)',43.6858274,-79.2785293,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:49:54'),
(155,'90 Inniswood Drive','90 Inniswood Drive','90-inniswood-drive','M1R 1R4','ON','Scarborough Centre (21)',43.7393919,-79.303365,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:49:55'),
(156,'82 Ainsdale Road','82 Ainsdale Road','82-ainsdale-road','M1R 3V8','ON','Scarborough Centre (21)',43.7509237,-79.2958293,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:49:57'),
(157,'131 Dorset Road','131 Dorset Road','131-dorset-road','M1M 0E1','ON','Scarborough Southwest\n(20)',43.7257172,-79.2338975,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:49:58'),
(158,'33 Budea Crescent','33 Budea Crescent','33-budea-crescent','M1R 2T6','ON','Scarborough Centre (21)',43.7629542,-79.3022869,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:50:00'),
(159,'299 Kennedy Road','299 Kennedy Road','299-kennedy-road','M1N 2M7','ON','Scarborough Southwest\n(20)',43.70957,-79.2584649,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:50:01'),
(160,'31 Briar Dale Boulevard','31 Briar Dale Boulevard','31-briar-dale-boulevard','M1N 2V8','ON','Scarborough Southwest\n(20)',43.6839133,-79.2779253,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:50:03'),
(161,'3115 Markham Road','3115 Markham Road','3115-markham-road','M1V 2W2','ON','Scarborough North (23)',43.8210726,-79.2465432,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:50:04'),
(162,'12 Gilroy Drive','12 Gilroy Drive','12-gilroy-drive','M1P 4V6','ON','Scarborough Centre (21)',43.7585724,-79.2800968,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:50:06'),
(163,'123 Bexhill Avenue','123 Bexhill Avenue','123-bexhill-avenue','M1L 3H1','ON','Scarborough Southwest\n(20)',43.7074729,-79.2908772,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:50:07'),
(164,'2 Emmeline Crescent','2 Emmeline Crescent','2-emmeline-crescent','M1S 3H5','ON','Scarborough-Agincourt\n(22)',43.7950519,-79.2841237,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:50:09'),
(165,'30 Gilder Drive','30 Gilder Drive','30-gilder-drive','M1K 2R5','ON','Scarborough Centre (21)',43.737136,-79.2564961,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:50:10'),
(166,'27 Shirley Crescent','27 Shirley Crescent','27-shirley-crescent','M1M 3B1','ON','Scarborough Guildwood\n(24)',43.7376194,-79.2150567,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:50:12'),
(167,'235 Bellamy Road North','235 Bellamy Road North','235-bellamy-road-north','M1J 2V6','ON','Scarborough Guildwood\n(24)',43.7487085,-79.2317808,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:50:13'),
(168,'15 Doerr Road','15 Doerr Road','15-doerr-road','M1P 4M2','ON','Scarborough Centre (21)',43.766778,-79.2579151,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:50:15'),
(169,'1 Wythenshawe Wood','1 Wythenshawe Wood','1-wythenshawe-wood','M1E 1S4','ON','Scarborough Guildwood\n(24)',43.7526056,-79.1929259,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:50:16'),
(170,'4410 Kingston Road','4410 Kingston Road','4410-kingston-road',NULL,'ON','Scarborough Guildwood\n(24)',44.7691714,-76.1698822,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:50:18'),
(171,'37 Lynndale Road','37 Lynndale Road','37-lynndale-road','M1N 2V8','ON','Scarborough Southwest\n(20)',43.6819357,-79.2760721,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:50:19'),
(172,'86 North Woodrow Boulevard','86 North Woodrow Boulevard','86-north-woodrow-boulevard','M1K 1W3','ON','Scarborough Southwest\n(20)',43.7116655,-79.2654998,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:50:21'),
(173,'38 Anndale Road','38 Anndale Road','38-anndale-road','M1N 2V8','ON','Scarborough Southwest\n(20)',43.6830564,-79.2763841,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:50:22'),
(174,'161 Treverton Drive','161 Treverton Drive','161-treverton-drive','M1K 3W5','ON','Scarborough Centre (21)',43.741087,-79.2676227,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:50:24'),
(175,'91 Commonwealth Avenue','91 Commonwealth Avenue','91-commonwealth-avenue','M1K 4C9','ON','Scarborough Southwest\n(20)',43.7324484,-79.2557115,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:50:26'),
(176,'94 Elinor Avenue','94 Elinor Avenue','94-elinor-avenue','M1R 3J6','ON','Scarborough Centre (21)',43.7505486,-79.3032505,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:50:27'),
(177,'54 Lauralynn Crescent','54 Lauralynn Crescent','54-lauralynn-crescent','M1S 2J3','ON','Scarborough North (23)',43.7942478,-79.2766775,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:50:29'),
(178,'12 Cliffcrest Drive','12 Cliffcrest Drive','12-cliffcrest-drive','M1M 1A2','ON','Scarborough Southwest\n(20)',43.7063155,-79.2439016,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:50:30'),
(179,'320 West Point Avenue','320 West Point Avenue','320-west-point-avenue','M1C 2Z2','ON','Scarborough Rouge-Park\n(25)',43.7944774,-79.1245665,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:50:32'),
(180,'593 Danforth Road','593 Danforth Road','593-danforth-road','M1K 2A8','ON','Scarborough Southwest\n(20)',43.7124511,-79.2620519,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:50:33'),
(181,'143 Chester Le Boulevard','143 Chester Le Boulevard','143-chester-le-boulevard','M1W 2K7','ON','Scarborough-Agincourt\n(22)',43.7963907,-79.3299165,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:50:35'),
(182,'42 Cedarview Drive','42 Cedarview Drive','42-cedarview-drive','M1C 0C3','ON','Scarborough-Rouge Park\n(25)',43.7893208,-79.1551074,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:50:36'),
(183,'30 Lakeside Avenue','30 Lakeside Avenue','30-lakeside-avenue','M1N 1S2','ON','Scarborough Southwest\n(20)',43.6881362,-79.2652397,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:50:38'),
(184,'1515 Birchmount Road','1515 Birchmount Road','1515-birchmount-road','M1R 5G2','ON','Scarborough Centre (21)',43.7588142,-79.2892663,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:50:39'),
(185,'125 Applefield Drive','125 Applefield Drive','125-applefield-drive','M1P 4M2','ON','Scarborough Centre (21)',43.7680481,-79.2616415,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:50:41'),
(186,'18 East Road','18 East Road','18-east-road','M1N 2V8','ON','Scarborough Southwest\n(20)',43.6880615,-79.2720453,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:50:44'),
(187,'34 Fallingbrook Drive','34 Fallingbrook Drive','34-fallingbrook-drive','L3C 1Y5','ON','Scarborough Southwest\n(20)',43.0267013,-79.2864779,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:50:46'),
(188,'5 Waldock Street','5 Waldock Street','5-waldock-street','M1E 2E5','ON','Scarborough-Guildwood\n(24)',43.7581241,-79.1927855,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:50:47'),
(189,'124 Denton Avenue','124 Denton Avenue','124-denton-avenue','M1N 3P1','ON','Scarborough Southwest\n(20)',43.6956388,-79.2770098,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:50:49'),
(190,'3660 Midland Avenue','3660 Midland Avenue','3660-midland-avenue','M1V 5L3','ON','Scarborough-Agincourt\n(22)',43.813419,-79.2921838,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:50:51'),
(191,'5 Avalon Boulevard','5 Avalon Boulevard','5-avalon-boulevard','M1N 1S5','ON','Scarborough Southwest\n(20)',43.6925821,-79.2640539,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:50:52'),
(192,'370 Beechgrove Drive','370 Beechgrove Drive','370-beechgrove-drive','M1E 2P9','ON','Scarborough-Rouge Park\n(25)',43.7767867,-79.1705193,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:50:54'),
(193,'3379 Lawrence Avenue East','3379 Lawrence Avenue East','3379-lawrence-avenue-east','M1H 1B3','ON','Scarborough-Guildwood\n(24)',43.7579382,-79.2335585,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:50:55'),
(194,'51 Morningside Avenue','51 Morningside Avenue','51-morningside-avenue','M1E 3C2','ON','Scarborough-Rouge Park\n(25)',43.7555085,-79.1803178,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:50:57'),
(195,'67 Sandown Avenue','67 Sandown Avenue','67-sandown-avenue','M1N 4A7','ON','Scarborough Southwest\n(20)',43.712607,-79.2524219,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:50:58'),
(196,'537 Kennedy Road','537 Kennedy Road','537-kennedy-road','M1K 3G5','ON','Scarborough Southwest\n(20)',43.7206288,-79.2627939,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:51:00'),
(197,'1143 Morningside Avenue','1143 Morningside Avenue','1143-morningside-avenue','M1B 3A4','ON','Scarborough-Rouge Park\n(25)',43.80065,-79.1989399,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:51:01'),
(198,'127 Claremore Avenue','127 Claremore Avenue','127-claremore-avenue','M1K 1A8','ON','Scarborough Southwest\n(20)',43.7109898,-79.2566626,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:51:03'),
(199,'30 Kenworthy Avenue','30 Kenworthy Avenue','30-kenworthy-avenue','M1L 3E4','ON','Scarborough Southwest\n(20)',43.6914955,-79.2836968,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:51:04'),
(200,'1703 Pharmacy Avenue','1703 Pharmacy Avenue','1703-pharmacy-avenue','M1R 2L2','ON','Scarborough-Agincourt\n(22)',43.7700873,-79.3146603,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:51:05'),
(201,'26 Neilson Avenue','26 Neilson Avenue','26-neilson-avenue','M1M 1C7','ON','Scarborough Southwest\n(20)',43.7187755,-79.2319894,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:51:07'),
(202,'39 Thatcher Avenue','39 Thatcher Avenue','39-thatcher-avenue','M1M 3X4','ON','Scarborough Southwest\n(20)',43.7171405,-79.2389873,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:51:08'),
(203,'2 Dorine Crescent','2 Dorine Crescent','2-dorine-crescent','M1L 1V6','ON','Scarborough Southwest\n(20)',43.7128199,-79.2919383,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:51:10'),
(204,'34 Heather Road','34 Heather Road','34-heather-road','R2J 1L3','ON','Scarborough North (23)',49.8676016,-97.0755636,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:51:11'),
(205,'105 Prairie Drive','105 Prairie Drive','105-prairie-drive','M1L 3Z3','ON','Scarborough Southwest\n(20)',43.6986281,-79.2796787,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:51:13'),
(206,'2328 Kingston Road','2328 Kingston Road','2328-kingston-road','M1N 1T0','ON','Scarborough Southwest\n(20)',43.7065452,-79.2514488,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:51:14'),
(207,'1302 Ellesmere Road','1302 Ellesmere Road','1302-ellesmere-road','M1P 2X8','ON','Scarborough Centre (21)',43.769839,-79.2642869,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:51:16'),
(208,'1415 Military Trail','1415 Military Trail','1415-military-trail','M1C 1A8','ON','Scarborough-Rouge Park\n(25)',43.782171,-79.1770484,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:51:18'),
(209,'8 Harewood Avenue','8 Harewood Avenue','8-harewood-avenue','M1M 1C7','ON','Scarborough Southwest\n(20)',43.7178204,-79.2329074,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:51:20'),
(210,'55 Rhydwen Avenue','55 Rhydwen Avenue','55-rhydwen-avenue','M1N 3J7','ON','Scarborough Southwest\n(20)',43.6955234,-79.2640342,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:51:21'),
(211,'3171 Eglinton Avenue East','3171 Eglinton Avenue East','3171-eglinton-avenue-east','M1J 3B4','ON','Scarborough Southwest\n(20)',43.742152,-79.2204896,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:51:23'),
(212,'2 Lejune Road','2 Lejune Road','2-lejune-road','M1T 2T6','ON','Scarborough-Agincourt\n(22)',43.7782676,-79.2883437,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:51:24'),
(213,'96 Toynbee Trail','96 Toynbee Trail','96-toynbee-trail','M1E 1P5','ON','Scarborough-Guildwood\n(24)',43.7509568,-79.1920601,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:51:26'),
(214,'137 August Avenue','137 August Avenue','137-august-avenue','M1L 3P1','ON','Scarborough Southwest\n(20)',43.696289,-79.2825393,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:51:27'),
(215,'4 Lejune Road','4 Lejune Road','4-lejune-road','M1T 2T6','ON','Scarborough-Agincourt\n(22)',43.7784006,-79.2885019,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:51:29'),
(216,'816 Meadowvale Road','816 Meadowvale Road','816-meadowvale-road','M1C 1T1','ON','Scarborough-Rouge Park\n(25)',43.7978928,-79.1658329,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:51:30'),
(217,'12 Janray Drive','12 Janray Drive','12-janray-drive','M1G 1Y2','ON','Scarborough-Guildwood\n(24)',43.7626689,-79.220634,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:51:32'),
(219,'90 Gradwell Drive','90 Gradwell Drive','90-gradwell-drive','M1M 3X4','ON','Scarborough Southwest\n(20)',43.7169557,-79.2364942,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:51:35'),
(220,'56 Oakley Boulevard','56 Oakley Boulevard','56-oakley-boulevard','M1P 3S4','ON','Scarborough Centre (21)',43.7639446,-79.2687566,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:51:36'),
(221,'129 Haslam Street','129 Haslam Street','129-haslam-street','M1K 1A8','ON','Scarborough Southwest\n(20)',43.707728,-79.2592166,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:51:37'),
(222,'132 Lansbury Drive','132 Lansbury Drive','132-lansbury-drive','M1V 0C1','ON','Scarborough North (23)',43.8180163,-79.2614799,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:51:39'),
(223,'5373 Finch Avenue East','5373 Finch Avenue East','5373-finch-avenue-east','M1S 5W2','ON','Scarborough North (23)',43.809994,-79.2500698,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:51:40'),
(224,'4 Birchmount Road','4 Birchmount Road','4-birchmount-road','M1N 1S5','ON','Scarborough Southwest\n(20)',43.6911566,-79.2617587,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:51:42'),
(225,'146 Island Road','146 Island Road','146-island-road','M1C 2X8','ON','Scarborough-Rouge Park\n(25)',43.7986822,-79.1367611,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:51:44'),
(226,'59 Copping Road','59 Copping Road','59-copping-road','M1G 3G9','ON','Scarborough-Guildwood\n(24)',43.7717997,-79.2012799,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:51:45'),
(227,'2 Kingsbury Crescent','2 Kingsbury Crescent','2-kingsbury-crescent','M1N 1S5','ON','Scarborough Southwest\n(20)',43.6885224,-79.265076,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:51:46'),
(228,'799 Midland Avenue','799 Midland Avenue','799-midland-avenue','M1K 4C9','ON','Scarborough Southwest\n(20)',43.7334585,-79.2574677,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:51:48'),
(230,'23 Richbourne Court','23 Richbourne Court','23-richbourne-court','M1T 1V7','ON','Scarborough-Agincourt\n(22)',43.7822104,-79.3103786,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:51:51'),
(231,'252 Tower Drive','252 Tower Drive','252-tower-drive','M1R 2R9','ON','Scarborough Centre (21)',43.7554745,-79.2967047,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:51:52'),
(232,'42 Armitage Drive','42 Armitage Drive','42-armitage-drive','M1R 2T6','ON','Scarborough Centre (21)',43.7680395,-79.3076294,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:51:54'),
(233,'132 Ellington Drive','132 Ellington Drive','132-ellington-drive','M1R 3V8','ON','Scarborough Centre (21)',43.7541274,-79.2936454,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:51:55'),
(234,'49 Portsmouth Drive','49 Portsmouth Drive','49-portsmouth-drive','M1C 5B9','ON','Scarborough-Rouge Park\n(25)',43.7756141,-79.1426247,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:51:56'),
(235,'102 Bexhill Avenue','102 Bexhill Avenue','102-bexhill-avenue','M1L 3H1','ON','Scarborough Southwest\n(20)',43.7060842,-79.2905385,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:51:58'),
(236,'24 Kingswell Crescent','24 Kingswell Crescent','24-kingswell-crescent','M1L 2X1','ON','Scarborough Southwest\n(20)',43.7190332,-79.2963663,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:51:59'),
(237,'20 Rockwood Drive','20 Rockwood Drive','20-rockwood-drive','M1M 1P2','ON','Scarborough Southwest\n(20)',43.7293135,-79.2298167,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:52:01'),
(238,'17 South Edgely Avenue','17 South Edgely Avenue','17-south-edgely-avenue','M1N 2G2','ON','Scarborough Southwest\n(20)',43.6990067,-79.2612736,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:52:02'),
(239,'10 Wexford Boulevard','10 Wexford Boulevard','10-wexford-boulevard','M1R 2G8','ON','Scarborough Centre (21)',43.735735,-79.2981227,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:52:04'),
(240,'315 Birchmount Road','315 Birchmount Road','315-birchmount-road','M1N 3J7','ON','Scarborough Southwest\n(20)',43.6988523,-79.2645499,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:52:05'),
(241,'18 Agincourt Drive','18 Agincourt Drive','18-agincourt-drive','M1S 1N3','ON','Scarborough Agincourt\n(22)',43.78566,-79.2830071,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:52:07'),
(242,'880 Ellesmere Road','880 Ellesmere Road','880-ellesmere-road','M1P 2L9','ON','Scarborough Centre (21)',43.7659483,-79.2813494,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:52:08'),
(243,'8 Chancellor Drive','8 Chancellor Drive','8-chancellor-drive','M1G 3M7','ON','Scarborough\nGuildwood(24)',43.7761274,-79.2251437,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:52:10'),
(244,'1195 Pharmacy Avenue','1195 Pharmacy Avenue','1195-pharmacy-avenue','M1R 2H7','ON','Scarborough Centre (21)',43.7457382,-79.3054552,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:52:11'),
(247,'31 Midholm Drive','31 Midholm Drive','31-midholm-drive','M1K 2P3','ON','Scarborough Centre (21)',43.7357593,-79.270815,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:52:16'),
(248,'39 Comstock Road','39 Comstock Road','39-comstock-road','M1L 4V9','ON','Scarborough Southwest\n(20)',43.7200273,-79.2906366,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:52:17'),
(249,'84 Santamonica Boulevard','84 Santamonica Boulevard','84-santamonica-boulevard','M1L 4R6','ON','Scarborough Southwest\n(20)',43.7074178,-79.2754515,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:52:19'),
(250,'807 Kennedy Road','807 Kennedy Road','807-kennedy-road','M1K 2P3','ON','Scarborough Centre (21)',43.7337025,-79.267941,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:52:20'),
(251,'533 Kennedy Road','533 Kennedy Road','533-kennedy-road','M1K 3G5','ON','Scarborough Southwest\n(20)',43.7204234,-79.262706,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:52:22'),
(252,'599 Kennedy Road','599 Kennedy Road','599-kennedy-road','M1K 3G5','ON','Scarborough Southwest\n(20)',43.724316,-79.2643883,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:52:24'),
(253,'119 Neddie Drive','119 Neddie Drive','119-neddie-drive','M1T 2T6','ON','Scarborough-Agincourt\n(22)',43.7810052,-79.2921525,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:52:25'),
(254,'99 Brantwood Drive','99 Brantwood Drive','99-brantwood-drive','M1H 1M4','ON','Scarborough Guildwood\n(20)',43.7649188,-79.2445368,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:52:26'),
(255,'172 Manse Road','172 Manse Road','172-manse-road','M1E 3T9','ON','Scarborough Rouge Park\n(25)',43.7642523,-79.1737651,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:52:28'),
(256,'31 Scarboro Avenue','31 Scarboro Avenue','31-scarboro-avenue','M1C 5H3','ON','Scarborough Rouge Park\n(25)',43.7924745,-79.1705279,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:52:29'),
(257,'2180 Lawrence Avenue East','2180 Lawrence Avenue East','2180-lawrence-avenue-east','M1P 2E3','ON','Scarborough Centre (21)',43.7480823,-79.2844839,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:52:31'),
(258,'70 Watson Street','70 Watson Street','70-watson-street','M1C 4Z1','ON','Scarborough-Rouge Park\n(25)',43.7867562,-79.1744888,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:52:33'),
(259,'3268 Finch Avenue East','3268 Finch Avenue East','3268-finch-avenue-east','M1W 1S8','ON','Scarborough Agincourt\n(22)',43.7966368,-79.3168073,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:52:34'),
(260,'3 Joy Drive','3 Joy Drive','3-joy-drive','M1R 3V3','ON','Scarborough Centre (21)',43.7513853,-79.3032668,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:52:36'),
(261,'80 Scottfield Drive','80 Scottfield Drive','80-scottfield-drive','M1S 5R4','ON','Scarborough North (23)',43.8085789,-79.2533989,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:52:37'),
(262,'1845 Birchmount Road','1845 Birchmount Road','1845-birchmount-road','M1W 2H5','ON','Scarborough Centre (21)',43.7679265,-79.29083,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:52:39'),
(263,'14 Goldberry Square','14 Goldberry Square','14-goldberry-square','M1C 1W7','ON','Scarborough-Rouge Park\n(25)',43.7775105,-79.1524443,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:52:40'),
(264,'49 Bellamy Road South','49 Bellamy Road South','49-bellamy-road-south','M1M 3R2','ON','Scarborough Southwest\n(20)',43.7367425,-79.2263616,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:52:42'),
(265,'748 Pharmacy Avenue','748 Pharmacy Avenue','748-pharmacy-avenue','M1L 2K1','ON','Scarborough Southwest\n(20)',43.7199034,-79.2953707,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:52:43'),
(266,'19 Araman Drive','19 Araman Drive','19-araman-drive','M1T 2T6','ON','Scarborough-Agincourt\n(22)',43.7756049,-79.2930938,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:52:45'),
(267,'16 Horfield Avenue','16 Horfield Avenue','16-horfield-avenue','M1M 1Z3','ON','Scarborough Southwest\n(20)',43.7277147,-79.2375012,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:52:47'),
(268,'11 Robertsfield Crescent','11 Robertsfield Crescent','11-robertsfield-crescent','M1R 2J1','ON','Scarborough Centre (21)',43.753638,-79.3105979,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:52:49'),
(269,'32 Eastville Avenue','32 Eastville Avenue','32-eastville-avenue','M1M 1C7','ON','Scarborough Southwest\n(20)',43.714335,-79.2340825,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:52:50'),
(270,'26 Natal Avenue','26 Natal Avenue','26-natal-avenue','M1N 2M7','ON','Scarborough Southwest\n(20)',43.7093595,-79.2525773,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:52:52'),
(271,'1063 Markham Road','1063 Markham Road, Unit 102','1063-markham-road-unit-102','M1H 3B7','ON','Scarborough-Guildwood\n(24)',43.7744866,-79.230866,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:52:53'),
(272,'67 Slan Avenue','67 Slan Avenue','67-slan-avenue','M1G 3B5','ON','Scarborough-Guildwood\n(24)',43.7743801,-79.2159332,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:52:55'),
(273,'19 Littleleaf Drive','19 Littleleaf Drive','19-littleleaf-drive','M1B 1P6','ON','Scarborough North (23)',43.7999151,-79.2320075,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:52:56'),
(274,'18 Spall Court','18 Spall Court','18-spall-court','M1C 3T7','ON','Scarborough-Rouge Park\n(25)',43.7900271,-79.1782992,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:52:57'),
(275,'33 Robertsfield Crescent','33 Robertsfield Crescent','33-robertsfield-crescent','M1R 4B9','ON','Scarborough Centre (21)',43.7548616,-79.3114389,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:52:59'),
(276,'22 Anson Avenue','22 Anson Avenue','22-anson-avenue','L8T 2R8','ON','Scarborough Southwest\n(20)',43.213073,-79.8325679,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:53:00'),
(277,'92 Courcelette Road','92 Courcelette Road','92-courcelette-road','M1N 2T6','ON','Scarborough Southwest\n(20)',43.6782135,-79.2788968,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:53:02'),
(278,'71 Kirker Avenue','71 Kirker Avenue','71-kirker-avenue','M1G 1P1','ON','Scarborough-Guildwood\n(24)',43.7589746,-79.2058936,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:53:03'),
(279,'312 Taylor Road','312 Taylor Road','312-taylor-road','M1C 2Z2','ON','Scarborough-Rouge Park\n(25)',43.794392,-79.1258598,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:53:05'),
(280,'1 Braeburn Boulevard','1 Braeburn Boulevard','1-braeburn-boulevard','M1J 2V6','ON','Scarborough Centre (21)',43.7486848,-79.2353889,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:53:07'),
(281,'3117 St','3117 St. Clair Avenue East','3117-st-clair-avenue-east','P0R 1G0','ON','Scarborough Southwest\n(20)',46.2583479,-83.8896035,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:53:09'),
(282,'2500 Lawrence Avenue East','2500 Lawrence Avenue East','2500-lawrence-avenue-east','M1P 4X1','ON','Scarborough Centre (21)',43.752323,-79.2678947,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:53:10'),
(283,'3-15 Lenthall Avenue','3-15 Lenthall Avenue -> 3 Lenthall Avenue','3-15-lenthall-avenue-3-lenthall-avenue','M1B 2W2','ON','Scarborough North (23)',43.7977601,-79.238315,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:53:12'),
(284,'171 Santamonica Boulevard','171 Santamonica Boulevard','171-santamonica-boulevard','M1L 4R6','ON','Scarborough Southwest\n(20)',43.7110703,-79.2766986,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:53:13'),
(285,'41 Kilchurn Castle Drive','41 Kilchurn Castle Drive','41-kilchurn-castle-drive','M1S 1H5','ON','Scarborough- Agincourt\n(22)',43.7931164,-79.2940254,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:53:15'),
(287,'67 Petworth Crescent','67 Petworth Crescent','67-petworth-crescent','M1S 3H5','ON','Scarborough- Agincourt\n(22)',43.7989626,-79.288707,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:53:18'),
(288,'3441 Lawrence Avenue East','3441 Lawrence Avenue East','3441-lawrence-avenue-east','M1H 1B3','ON','Scarborough- Guildwood\n(24)',43.7583668,-79.2309363,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:53:19'),
(289,'71 North Edgely Avenue','71 North Edgely Avenue','71-north-edgely-avenue','M1K 1W3','ON','Scarborough Southwest\n(20)',43.7083043,-79.2649153,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:53:20'),
(291,'7 Landry Avenue','7 Landry Avenue','7-landry-avenue','M1L 1C6','ON','Scarborough Southwest\n(20)',43.6943805,-79.2777309,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:53:24'),
(292,'8 Lockie Avenue','8 Lockie Avenue','8-lockie-avenue','M1S 1N3','ON','Scarborough- Agincourt\n(22)',43.7883346,-79.2831348,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:53:26'),
(293,'58 South Woodrow Boulevard','58 South Woodrow Boulevard','58-south-woodrow-boulevard','M1N 2J1','ON','Scarborough Southwest\n(20)',43.6997432,-79.2605888,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:53:27'),
(294,'46 Emmeline Crescent','46 Emmeline Crescent','46-emmeline-crescent','M1S 3H5','ON','Scarborough- Agincourt\n(22)',43.7954318,-79.2873154,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:53:29'),
(295,'73 Neilson Avenue','73 Neilson Avenue','73-neilson-avenue','M1M 1N3','ON','Scarborough Southwest\n(20)',43.7215472,-79.232886,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:53:30'),
(296,'3459 Sheppard Avenue East','3459 Sheppard Avenue East','3459-sheppard-avenue-east','M1T 3K7','ON','Scarborough- Agincourt\n(22)',43.7792536,-79.3050725,1,NULL,NULL,'2025-05-02 07:44:04','2025-05-02 07:53:32'),
(297,'127 Euclid Avenue','127 Euclid Avenue','127-euclid-avenue','M1C 1T1','ON','Scarborough-Rouge Park\n(25)',43.7952511,-79.1677631,1,NULL,NULL,'2025-05-02 07:44:05','2025-05-02 07:53:34'),
(298,'71 Vanbrugh Avenue','71 Vanbrugh Avenue','71-vanbrugh-avenue','M1N 2M7','ON','Scarborough Southwest\n(20)',43.7097952,-79.2549497,1,NULL,NULL,'2025-05-02 07:44:05','2025-05-02 07:53:35'),
(299,'39 Brenda Crescent','39 Brenda Crescent','39-brenda-crescent','M1K 3G5','ON','Scarborough Southwest\n(20)',43.7193179,-79.2593327,1,NULL,NULL,'2025-05-02 07:44:05','2025-05-02 07:53:36'),
(300,'2 Pine Ridge Drive','2 Pine Ridge Drive','2-pine-ridge-drive','M1M 1P2','ON','Scarborough Southwest\n(20)',43.7267807,-79.2249198,1,NULL,NULL,'2025-05-02 07:44:05','2025-05-02 07:53:39'),
(301,'144 Bexhill Avenue','144 Bexhill Avenue','144-bexhill-avenue','M1L 3H1','ON','Scarborough Southwest\n(20)',43.709075,-79.2918139,1,NULL,NULL,'2025-05-02 07:44:05','2025-05-02 07:53:40'),
(302,'24 Pine Ridge Drive','24 Pine Ridge Drive','24-pine-ridge-drive','M1M 3N8','ON','Scarborough Southwest\n(20)',43.7282229,-79.2236255,1,NULL,NULL,'2025-05-02 07:44:05','2025-05-02 07:53:42'),
(303,'51 Brenda Crescent','51 Brenda Crescent','51-brenda-crescent','M1K 1G5','ON','Scarborough Southwest\n(20)',43.7199778,-79.2588264,1,NULL,NULL,'2025-05-02 07:44:05','2025-05-02 07:53:44'),
(304,'958 Milner Avenue','958 Milner Avenue','958-milner-avenue','M1B 5X4','ON','Scarborough-Rouge Park\n(25)',43.7997337,-79.1915689,1,NULL,NULL,'2025-05-02 07:44:05','2025-05-02 07:53:46'),
(305,'196 Generation Boulevard','196 Generation Boulevard','196-generation-boulevard','M1B 2K5','ON','Scarborough- Rouge Park\n(25)',43.8027266,-79.1630983,1,NULL,NULL,'2025-05-02 07:44:05','2025-05-02 07:53:47'),
(306,'5280 Finch Avenue East','5280 Finch Avenue East','5280-finch-avenue-east','M2H 3N6','ON','Scarborough North (23)',43.7903837,-79.365243,1,NULL,NULL,'2025-05-02 07:44:05','2025-05-02 07:53:49'),
(307,'88 Craiglee Drive','88 Craiglee Drive','88-craiglee-drive','M1N 2M7','ON','Scarborough Southwest\n(20)',43.7065292,-79.2539032,1,NULL,NULL,'2025-05-02 07:44:05','2025-05-02 07:53:51'),
(308,'777 Victoria Park Avenue','777 Victoria Park Avenue','777-victoria-park-avenue','M1L 1B1','ON','Scarborough Southwest\n(20)',43.6930652,-79.2889067,1,NULL,NULL,'2025-05-02 07:44:05','2025-05-02 07:53:52'),
(309,'1-70 Eglinton Square','1-70 Eglinton Square (or) 1431 Victoria Park Avenue','1-70-eglinton-square-or-1431-victoria-park-avenue','M4A 2M2','ON','Scarborough Southwest\n(20)',43.7235479,-79.3019764,1,NULL,NULL,'2025-05-02 07:44:05','2025-05-02 07:53:55'),
(310,'47 Cliffside Drive','47 Cliffside Drive','47-cliffside-drive','M1N 1M1','ON','Scarborough Southwest\n(20)',43.7038266,-79.2500538,1,NULL,NULL,'2025-05-02 07:44:05','2025-05-02 07:53:57'),
(312,'35 Tara Avenue','35 Tara Avenue','35-tara-avenue','M1K 3W5','ON','Scarborough Centre\n(21)',43.7425005,-79.2635897,1,NULL,NULL,'2025-05-02 07:44:05','2025-05-02 07:54:00'),
(313,'5297 Lawrence Avenue East','5297 Lawrence Avenue East','5297-lawrence-avenue-east','M1C 1W7','ON','Scarborough-Rouge\nPark (25)',43.7763718,-79.1502841,1,NULL,NULL,'2025-05-02 07:44:05','2025-05-02 07:54:02'),
(314,'35 Shandara Crescent','35 Shandara Crescent','35-shandara-crescent','M1R 2H1','ON','Scarborough Centre\n(21)',43.7372892,-79.3036149,1,NULL,NULL,'2025-05-02 07:44:05','2025-05-02 07:54:03'),
(315,'4 Trelevan Place','4 Trelevan Place','4-trelevan-place','M1R 2Z3','ON','Scarborough Centre\n(21)',43.7429868,-79.2919889,1,NULL,NULL,'2025-05-02 07:44:05','2025-05-02 07:54:05'),
(318,'266A Kennedy Road','266A Kennedy Road','266a-kennedy-road','K0A 3J0','ON','Scarborough Southwest\n(20)',45.148915,-75.4441649,1,NULL,NULL,'2025-05-02 07:44:05','2025-05-02 07:54:10'),
(319,'21 Canadine Road','21 Canadine Road','21-canadine-road','M1P 2X6','ON','Scarborough Centre\n(21)',43.7667695,-79.2692254,1,NULL,NULL,'2025-05-02 07:44:05','2025-05-02 07:54:11'),
(320,'27 Glen Muir Drive','27 Glen Muir Drive','27-glen-muir-drive','M1M 3R2','ON','Scarborough Southwest\n(20)',43.7364449,-79.2286379,1,NULL,NULL,'2025-05-02 07:44:05','2025-05-02 07:54:12'),
(321,'132 Canlish Road','132 Canlish Road','132-canlish-road','M1P 1M2','ON','Scarborough Centre\n(21)',43.7555591,-79.2845401,1,NULL,NULL,'2025-05-02 07:44:05','2025-05-02 07:54:14'),
(323,'50 Danforth Road','50 Danforth Road','50-danforth-road','M1L 3W5','ON','Scarborough Southwest\n(20)',43.6954794,-79.2760835,1,NULL,NULL,'2025-05-02 07:44:05','2025-05-02 07:54:17'),
(324,'917 Victoria Park Avenue','917 Victoria Park Avenue','917-victoria-park-avenue','M4B 2E6','ON','Scarborough Southwest\n(20)',43.70106,-79.292413,1,NULL,NULL,'2025-05-02 07:44:05','2025-05-02 07:54:18'),
(325,'1680 Brimley Road','1680 Brimley Road','1680-brimley-road','M1P 0A3','ON','Scarborough Centre (21)',43.7746254,-79.2631069,1,NULL,NULL,'2025-05-02 07:44:05','2025-05-02 07:54:20'),
(326,'98 Pitt Avenue','98 Pitt Avenue','98-pitt-avenue','M1L 1T4','ON','Scarborough Southwest\n(20',43.7051424,-79.2934096,1,NULL,NULL,'2025-05-02 07:44:05','2025-05-02 07:54:21'),
(327,'59 Heather Road','59 Heather Road','59-heather-road','M1S 2E2','ON','Scarborough North (23)',43.7903949,-79.2701293,1,NULL,NULL,'2025-05-02 07:44:05','2025-05-02 07:54:23'),
(329,'130 Barbados Boulevard','130 Barbados Boulevard','130-barbados-boulevard','M1J 0A2','ON','Scarborough Southwest\n(20)',43.7375388,-79.2411264,1,NULL,NULL,'2025-05-02 07:44:05','2025-05-02 07:54:26'),
(330,'3278 Midland Avenue','3278 Midland Avenue','3278-midland-avenue','M1V 3Z9','ON','Scarborough-Agincourt\n(22)',43.8054055,-79.2887126,1,NULL,NULL,'2025-05-02 07:44:05','2025-05-02 07:54:28'),
(331,'16 Martindale Road','16 Martindale Road','16-martindale-road','M1M 1Z3','ON','Scarborough Southwest\n(20)',43.733286,-79.233887,1,NULL,NULL,'2025-05-02 07:44:05','2025-05-02 07:54:29'),
(332,'6 Rensburg Drive','6 Rensburg Drive','6-rensburg-drive','M1K 2N2','ON','Scarborough Centre (21)',43.732817,-79.271148,1,NULL,NULL,'2025-05-02 07:44:05','2025-05-02 07:54:31'),
(333,'228 Guildwood Parkway','228 Guildwood Parkway','228-guildwood-parkway','M1E 1R3','ON','Scarborough-Guildwood\n(24)',43.7491708,-79.1925497,1,NULL,NULL,'2025-05-02 07:44:05','2025-05-02 07:54:32'),
(334,'110 Manse Road','110 Manse Road','110-manse-road','M1E 3T9','ON','Scarborough-Rouge Park\n(25)',43.7600576,-79.1719564,1,NULL,NULL,'2025-05-02 07:44:05','2025-05-02 07:54:34'),
(335,'20 Stonehill Court','20 Stonehill Court','20-stonehill-court','M1W 2R5','ON','Scarborough-Agincourt\n(22)',43.7960585,-79.3147409,1,NULL,NULL,'2025-05-02 07:44:05','2025-05-02 07:54:35'),
(336,'167 Birkdale Road','167 Birkdale Road','167-birkdale-road','M1P 3S4','ON','Scarborough Centre (21)',43.7626925,-79.2647831,1,NULL,NULL,'2025-05-02 07:44:05','2025-05-02 07:54:37'),
(338,'1430 Birchmount Road','1430 Birchmount Road','1430-birchmount-road','M1P 2E3','ON','Scarborough Centre (21)',43.7519408,-79.2868201,1,NULL,NULL,'2025-05-02 07:44:05','2025-05-02 07:54:40'),
(339,'152 Audrey Avenue','152 Audrey Avenue','152-audrey-avenue','M1N 2V8','ON','Scarborough Southwest\n(20)',43.6863437,-79.2738954,1,NULL,NULL,'2025-05-02 07:44:05','2025-05-02 07:54:41'),
(340,'59 Foxridge Drive','59 Foxridge Drive','59-foxridge-drive','M1L 1Y5','ON','Scarborough Southwest\n(20)',43.7225062,-79.2699633,1,NULL,NULL,'2025-05-02 07:44:05','2025-05-02 07:54:44'),
(341,'448 Aylesworth Avenue','448 Aylesworth Avenue','448-aylesworth-avenue','M1N 2M7','ON','Scarborough Southwest\n(20)',43.7125769,-79.2549738,1,NULL,NULL,'2025-05-02 07:44:05','2025-05-02 07:54:45'),
(342,'11 Vauxhall Drive','11 Vauxhall Drive','11-vauxhall-drive','M1P 2P9','ON','Scarborough Centre (21)',43.7497172,-79.2831948,1,NULL,NULL,'2025-05-02 07:44:05','2025-05-02 07:54:47'),
(343,'23 Milliken Boulevard','23 Milliken Boulevard, B10','23-milliken-boulevard-b10','M1V 1S9','ON','Scarborough-Agincourt\n(22)',43.8036826,-79.2949717,1,NULL,NULL,'2025-05-02 07:44:05','2025-05-02 07:54:48'),
(344,'2601 Kingston Road','2601 Kingston Road','2601-kingston-road','M1N 4A7','ON','Scarborough Southwest\n(20)',43.7129263,-79.2459527,1,NULL,NULL,'2025-05-02 07:44:05','2025-05-02 07:54:50'),
(345,'345 Finchdene Square','345 Finchdene Square','345-finchdene-square','M1X 1C3','ON','Scarborough North (23)',43.8191014,-79.2376174,1,NULL,NULL,'2025-05-02 07:44:05','2025-05-02 07:54:52'),
(346,'1 Gaylord Drive','1 Gaylord Drive','1-gaylord-drive','M1R 5E5','ON','Scarborough Centre (21)',43.7335561,-79.3024785,1,NULL,NULL,'2025-05-02 07:44:05','2025-05-02 07:54:53'),
(347,'101 Minerva Avenue','101 Minerva Avenue','101-minerva-avenue','M1M 1X5','ON','Scarborough Southwest\n(20)',43.7219133,-79.244988,1,NULL,NULL,'2025-05-02 07:44:05','2025-05-02 07:54:55'),
(348,'54 Corinthian Boulevard','54 Corinthian Boulevard','54-corinthian-boulevard','M1W 1B3','ON','Scarborough-Agincourt\n(22)',43.7894248,-79.3285494,1,NULL,NULL,'2025-05-02 07:44:05','2025-05-02 07:54:56'),
(349,'487 Warden Avenue','487 Warden Avenue','487-warden-avenue','M1L 3W5','ON','Scarborough Southwest\n(20)',43.6958749,-79.2740849,1,NULL,NULL,'2025-05-02 07:44:05','2025-05-02 07:54:59'),
(350,'120 Nashdene Road','120 Nashdene Road','120-nashdene-road','M1V 5E4','ON','Scarborough North (23)',43.8196972,-79.2493213,1,NULL,NULL,'2025-05-02 07:44:05','2025-05-02 07:55:00'),
(351,'77 Ionview Road','77 Ionview Road','77-ionview-road','M1K 2Z9','ON','Scarborough Centre (21)',43.7369034,-79.2733175,1,NULL,NULL,'2025-05-02 07:44:05','2025-05-02 07:55:02'),
(352,'1385 Midland Avenue','1385 Midland Avenue','1385-midland-avenue','M1P 2S1','ON','Scarborough Centre (21)',43.7513192,-79.2648178,1,NULL,NULL,'2025-05-02 07:44:05','2025-05-02 07:55:03'),
(353,'3101 Kennedy Road','3101 Kennedy Road','3101-kennedy-road','M1V 1S9','ON','Scarborough-Agincourt\n(22)',43.8109672,-79.3011117,1,NULL,NULL,'2025-05-02 07:44:05','2025-05-02 07:55:05'),
(354,'15 Andrew Avenue','15 Andrew Avenue','15-andrew-avenue','M1M 1T2','ON','Scarborough Southwest\n(20)',43.7218291,-79.2451662,1,NULL,NULL,'2025-05-02 07:44:05','2025-05-02 07:55:07'),
(355,'296 Passmore Avenue','296 Passmore Avenue','296-passmore-avenue','M1V 5P6','ON','Scarborough North (23)',43.8276215,-79.2645886,1,NULL,NULL,'2025-05-02 07:44:05','2025-05-02 07:55:08'),
(356,'27 Annis Road','27 Annis Road','27-annis-road','M1M 3N8','ON','Scarborough Southwest\n(20)',43.7343791,-79.2188465,1,NULL,NULL,'2025-05-02 07:44:05','2025-05-02 07:55:10'),
(357,'187 Oakridge Drive','187 Oakridge Drive','187-oakridge-drive','M1M 1P2','ON','Scarborough Southwest\n(20)',43.7326912,-79.2310195,1,NULL,NULL,'2025-05-02 07:44:05','2025-05-02 07:55:12'),
(358,'46 Dempster Street','46 Dempster Street','46-dempster-street','M1T 2T6','ON','Scarborough-Agincourt\n(22)',43.7800434,-79.2921523,1,NULL,NULL,'2025-05-02 07:44:05','2025-05-02 07:55:13'),
(359,'1 Ranstone Gardens','1 Ranstone Gardens','1-ranstone-gardens','M1L 2P6','ON','Scarborough Centre (21)',43.7387714,-79.2803793,1,NULL,NULL,'2025-05-02 07:44:05','2025-05-02 07:55:15'),
(360,'53 Gaiety Drive','53 Gaiety Drive','53-gaiety-drive','M1H 1A7','ON','Scarborough Centre (21)',43.7565042,-79.2373353,1,NULL,NULL,'2025-05-02 07:44:05','2025-05-02 07:55:16'),
(361,'42 Pepper Tree Drive','42 Pepper Tree Drive','42-pepper-tree-drive','M1C 2C6','ON','Scarborough-Rouge\nPark (25)',43.7758853,-79.1440456,1,NULL,NULL,'2025-05-02 07:44:05','2025-05-02 07:55:18'),
(362,'4 Cotton Avenue','4 Cotton Avenue','4-cotton-avenue','M1K 2A8','ON','Scarborough Southwest\n(20)',43.7127878,-79.2624279,1,NULL,NULL,'2025-05-02 07:44:05','2025-05-02 07:55:19'),
(363,'107 Wayne Avenue','107 Wayne Avenue','107-wayne-avenue','M1S 2H3','ON','Scarborough Centre (21)',43.7426067,-79.2966717,1,NULL,NULL,'2025-05-02 07:44:05','2025-05-02 07:55:21'),
(364,'400 Manse Road','400 Manse Road','400-manse-road','V9P 2B7','ON','Scarborough-Rouge\nPark (25)',49.3285512,-124.346718,1,NULL,NULL,'2025-05-02 07:44:05','2025-05-02 07:55:22'),
(365,'76 Haslam Street','76 Haslam Street','76-haslam-street','M1K 1A8','ON','Scarborough Southwest\n(20)',43.7058884,-79.2587021,1,NULL,NULL,'2025-05-02 07:44:05','2025-05-02 07:55:24'),
(366,'41 Farmbrook Road','41 Farmbrook Road','41-farmbrook-road','M1J 2V6','ON','Scarborough-Guildwood\n(24)',43.7461256,-79.2283497,1,NULL,NULL,'2025-05-02 07:44:05','2025-05-02 07:55:25'),
(368,'100 Canadian Road','100 Canadian Road','100-canadian-road','M1R 5G2','ON','Scarborough Centre (21)',43.7614294,-79.2907892,1,NULL,NULL,'2025-05-02 07:44:05','2025-05-02 07:55:29'),
(369,'28 Parkland Road','28 Parkland Road','28-parkland-road','M1N 2S4','ON','Scarborough Southwest\n(20)',43.6851896,-79.2802921,1,NULL,NULL,'2025-05-02 07:44:05','2025-05-02 07:55:30'),
(370,'2250 Markham Road','2250 Markham Road','2250-markham-road','M1B 2W4','ON','Scarborough North (23)',43.8097166,-79.2434589,1,NULL,NULL,'2025-05-02 07:44:05','2025-05-02 07:55:33'),
(371,'130 Lilian Drive','130 Lilian Drive','130-lilian-drive','M1R 3V3','ON','Scarborough Centre (21)',43.7525782,-79.2991847,1,NULL,NULL,'2025-05-02 07:44:05','2025-05-02 07:55:35'),
(372,'293 Ridgewood Road','293 Ridgewood Road','293-ridgewood-road','M1C 4M5','ON','Scarborough- Rouge\nPark (25)',43.7912837,-79.1347127,1,NULL,NULL,'2025-05-02 07:44:05','2025-05-02 07:55:37'),
(373,'2 Robinson Avenue','2 Robinson Avenue','2-robinson-avenue','M1N 3P1','ON','Scarborough Southwest\n(20)',43.693446,-79.2791311,1,NULL,NULL,'2025-05-02 07:44:05','2025-05-02 07:55:38'),
(374,'1995 Markham Road','1995 Markham Road','1995-markham-road','M1B 2W4','ON','Scarborough North (23)',43.8042595,-79.2407317,1,NULL,NULL,'2025-05-02 07:44:05','2025-05-02 07:55:40'),
(375,'41 Shepmore Terrace','41 Shepmore Terrace','41-shepmore-terrace','M1B 2L2','ON','Scarborough North (23)',43.8024004,-79.2303861,1,NULL,NULL,'2025-05-02 07:44:05','2025-05-02 07:55:41'),
(377,'6 McGrath Court','6 McGrath Court','6-mcgrath-court','M1C 2A2','ON','Scarborough-Rouge\nPark (25)',43.7871539,-79.1472536,1,NULL,NULL,'2025-05-02 07:44:05','2025-05-02 07:55:45');
/*!40000 ALTER TABLE `locations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `meeting_videos`
--

DROP TABLE IF EXISTS `meeting_videos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `meeting_videos` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `url` text NOT NULL,
  `slug` text NOT NULL,
  `meeting_id` bigint(20) unsigned NOT NULL,
  `video_title` text NOT NULL,
  `video_duration` bigint(20) NOT NULL,
  `video_transcript` text DEFAULT NULL,
  `video_description` text DEFAULT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `meeting_videos_meeting_id_foreign` (`meeting_id`),
  KEY `meeting_videos_user_id_foreign` (`user_id`),
  CONSTRAINT `meeting_videos_meeting_id_foreign` FOREIGN KEY (`meeting_id`) REFERENCES `meetings` (`id`) ON DELETE CASCADE,
  CONSTRAINT `meeting_videos_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `meeting_videos`
--

LOCK TABLES `meeting_videos` WRITE;
/*!40000 ALTER TABLE `meeting_videos` DISABLE KEYS */;
INSERT INTO `meeting_videos` VALUES
(10,'https://www.youtube.com/watch?v=T3VOtSJAVRs','committee-of-adjustment-public-hearing-scarborough-april-9-2025-pm',4,'Committee of Adjustment, Public Hearing, Scarborough, April 9, 2025 (PM)',100,NULL,NULL,NULL,NULL,'2025-05-02 10:08:39','2025-05-02 10:08:39'),
(11,'https://www.youtube.com/watch?v=HTf26QgeG9M','committee-of-adjustment-public-hearing-scarborough-april-9-2025-am',4,'Committee of Adjustment, Public Hearing, Scarborough, April 9, 2025 (AM)',100,NULL,NULL,NULL,NULL,'2025-05-02 10:08:39','2025-05-02 10:08:39'),
(12,'https://www.youtube.com/watch?v=xT7ZVeNyNmQ','committee-of-adjustment-public-hearing-scarborough-march-12-2025-pm',3,'Committee of Adjustment, Public Hearing, Scarborough, March 12, 2025 (PM)',100,NULL,NULL,NULL,NULL,'2025-05-02 10:08:39','2025-05-02 10:08:39'),
(13,'https://www.youtube.com/watch?v=BJs0jLFdVxs','committee-of-adjustment-public-hearing-scarborough-march-12-2025-am',3,'Committee of Adjustment, Public Hearing, Scarborough, March 12, 2025 (AM)',100,NULL,NULL,NULL,NULL,'2025-05-02 10:08:39','2025-05-02 10:08:39'),
(14,'https://www.youtube.com/watch?v=zCCXTYdSr60','committee-of-adjustment-public-hearing-scarborough-february-12-2025-am',2,'Committee of Adjustment, Public Hearing, Scarborough, February 12, 2025 (AM)',100,NULL,NULL,NULL,NULL,'2025-05-02 10:08:39','2025-05-02 10:08:39'),
(15,'https://www.youtube.com/watch?v=8Uj5F5Zln7g','committee-of-adjustment-public-hearing-scarborough-january-16-2025-pm',1,'Committee of Adjustment, Public Hearing, Scarborough, January 16, 2025 (PM)',100,NULL,NULL,NULL,NULL,'2025-05-02 10:08:39','2025-05-02 10:08:39'),
(16,'https://www.youtube.com/watch?v=2IbDPJzuXnU','committee-of-adjustment-public-hearing-scarborough-january-16-2025-am',1,'Committee of Adjustment, Public Hearing, Scarborough, January 16, 2025 (AM)',100,NULL,NULL,NULL,NULL,'2025-05-02 10:08:39','2025-05-02 10:08:39'),
(17,'https://www.youtube.com/watch?v=cFWmeLmnqmI','committee-of-adjustment-public-hearing-scarborough-january-17-2024-am',6,'Committee of Adjustment, Public Hearing, Scarborough, January 17, 2024 (AM)',100,NULL,NULL,NULL,NULL,'2025-05-04 22:40:40','2025-05-04 22:40:40'),
(18,'https://www.youtube.com/watch?v=bb5bGjunD0E','committee-of-adjustment-public-hearing-scarborough-january-17-2024-pm',6,'Committee of Adjustment, Public Hearing, Scarborough, January 17, 2024 (PM)',100,NULL,NULL,NULL,NULL,'2025-05-04 22:40:40','2025-05-04 22:40:40'),
(19,'https://www.youtube.com/watch?v=Thpj8GAY9Ss','committee-of-adjustment-public-hearing-scarborough-february-14-2024-am',7,'Committee of Adjustment, Public Hearing, Scarborough, February 14, 2024 (AM)',100,NULL,NULL,NULL,NULL,'2025-05-04 22:40:40','2025-05-04 22:40:40'),
(20,'https://www.youtube.com/watch?v=4_YBbzwfqnA','committee-of-adjustment-public-hearing-scarborough-march-6-2024-am',8,'Committee of Adjustment, Public Hearing, Scarborough, March 6, 2024 (AM)',100,NULL,NULL,NULL,NULL,'2025-05-04 22:40:40','2025-05-04 22:40:40'),
(21,'https://www.youtube.com/watch?v=CY8P39klSm8','committee-of-adjustment-public-hearing-scarborough-april-3-2024-am',9,'Committee of Adjustment, Public Hearing, Scarborough, April 3, 2024 (AM)',100,NULL,NULL,NULL,NULL,'2025-05-04 22:40:40','2025-05-04 22:40:40'),
(22,'https://www.youtube.com/watch?v=8Iuz80XsWw0','committee-of-adjustment-public-hearing-scarborough-april-3-2024-pm',9,'Committee of Adjustment, Public Hearing, Scarborough, April 3, 2024 (PM)',100,NULL,NULL,NULL,NULL,'2025-05-04 22:40:40','2025-05-04 22:40:40'),
(23,'https://www.youtube.com/watch?v=7OFdvEXV4x4','committee-of-adjustment-public-hearing-scarborough-may-1-2024-am',10,'Committee of Adjustment, Public Hearing, Scarborough, May 1, 2024 (AM)',100,NULL,NULL,NULL,NULL,'2025-05-04 22:40:40','2025-05-04 22:40:40'),
(24,'https://www.youtube.com/watch?v=197w7iU37no','committee-of-adjustment-public-hearing-scarborough-may-1-2024-pm',10,'Committee of Adjustment, Public Hearing, Scarborough, May 1, 2024 (PM)',100,NULL,NULL,NULL,NULL,'2025-05-04 22:40:40','2025-05-04 22:40:40'),
(25,'https://www.youtube.com/watch?v=bP5NpGmlFxg','committee-of-adjustment-public-hearing-scarborough-june-5-2024-am',11,'Committee of Adjustment, Public Hearing, Scarborough, June 5, 2024 (AM)',100,NULL,NULL,NULL,NULL,'2025-05-04 22:40:40','2025-05-04 22:40:40'),
(26,'https://www.youtube.com/watch?v=3onRVpgNCms','committee-of-adjustment-public-hearing-scarborough-june-26-2024-am',12,'Committee of Adjustment, Public Hearing, Scarborough, June 26, 2024 (AM)',100,NULL,NULL,NULL,NULL,'2025-05-04 22:40:40','2025-05-04 22:40:40'),
(27,'https://www.youtube.com/watch?v=iOmRS2VgI3k','committee-of-adjustment-public-hearing-scarborough-june-26-2024-pm',12,'Committee of Adjustment, Public Hearing, Scarborough, June 26, 2024 (PM)',100,NULL,NULL,NULL,NULL,'2025-05-04 22:40:41','2025-05-04 22:40:41'),
(28,'https://www.youtube.com/watch?v=Scexulysq20','committee-of-adjustment-public-hearing-scarborough-july-24-2024-am',13,'Committee of Adjustment, Public Hearing, Scarborough, July 24, 2024 (AM)',100,NULL,NULL,NULL,NULL,'2025-05-04 22:40:41','2025-05-04 22:40:41'),
(29,'https://www.youtube.com/watch?v=2YY0EztZ4Dk','committee-of-adjustment-public-hearing-scarborough-july-24-2024-pm',13,'Committee of Adjustment, Public Hearing, Scarborough, July 24, 2024 (PM)',100,NULL,NULL,NULL,NULL,'2025-05-04 22:40:41','2025-05-04 22:40:41'),
(30,'https://www.youtube.com/watch?v=z6kzbJisYAs','committee-of-adjustment-public-hearing-scarborough-august-22-2024-am',14,'Committee of Adjustment, Public Hearing, Scarborough, August 22, 2024 (AM)',100,NULL,NULL,NULL,NULL,'2025-05-04 22:40:41','2025-05-04 22:40:41'),
(31,'https://www.youtube.com/watch?v=bBBUKiHI9xM','committee-of-adjustment-public-hearing-scarborough-september-18-2024-am',15,'Committee of Adjustment, Public Hearing, Scarborough, September 18, 2024 (AM)',100,NULL,NULL,NULL,NULL,'2025-05-04 22:40:41','2025-05-04 22:40:41'),
(32,'https://www.youtube.com/watch?v=VqiuCAoQYb8','committee-of-adjustment-public-hearing-scarborough-october-16-2024-am',16,'Committee of Adjustment, Public Hearing, Scarborough, October 16, 2024 (AM)',100,NULL,NULL,NULL,NULL,'2025-05-04 22:40:41','2025-05-04 22:40:41'),
(33,'https://www.youtube.com/watch?v=KPsfPxuQKaQ','committee-of-adjustment-public-hearing-scarborough-november-13-2024-am',17,'Committee of Adjustment, Public Hearing, Scarborough, November 13, 2024 (AM)',100,NULL,NULL,NULL,NULL,'2025-05-04 22:40:41','2025-05-04 22:40:41'),
(34,'https://www.youtube.com/watch?v=M4Mbiq6W31k','committee-of-adjustment-public-hearing-scarborough-november-13-2024-pm',17,'Committee of Adjustment, Public Hearing, Scarborough, November 13, 2024 (PM)',100,NULL,NULL,NULL,NULL,'2025-05-04 22:40:41','2025-05-04 22:40:41'),
(35,'https://www.youtube.com/watch?v=MR3G-pprX4o','committee-of-adjustment-public-hearing-scarborough-december-4-2024-am',18,'Committee of Adjustment, Public Hearing, Scarborough, December 4, 2024 (AM)',100,NULL,NULL,NULL,NULL,'2025-05-04 22:40:41','2025-05-04 22:40:41'),
(36,'https://www.youtube.com/watch?v=ZWjUgff7x8Q','committee-of-adjustment-public-hearing-scarborough-december-4-2024-pm',18,'Committee of Adjustment, Public Hearing, Scarborough, December 4, 2024 (PM)',100,NULL,NULL,NULL,NULL,'2025-05-04 22:40:42','2025-05-04 22:40:42');
/*!40000 ALTER TABLE `meeting_videos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `meetings`
--

DROP TABLE IF EXISTS `meetings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `meetings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `date` varchar(255) NOT NULL,
  `governing_committee` varchar(255) DEFAULT NULL,
  `district` varchar(255) NOT NULL,
  `hearing_time` varchar(255) DEFAULT NULL,
  `hearing_location` varchar(255) DEFAULT NULL,
  `url` text DEFAULT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `meetings_user_id_foreign` (`user_id`),
  KEY `meetings_updated_by_foreign` (`updated_by`),
  CONSTRAINT `meetings_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `meetings_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `meetings`
--

LOCK TABLES `meetings` WRITE;
/*!40000 ALTER TABLE `meetings` DISABLE KEYS */;
INSERT INTO `meetings` VALUES
(1,'2025-01-16-scarborough','January 16, 2025','2025-01-16','City of Toronto','Scarborough',NULL,NULL,'https://www.toronto.ca/wp-content/uploads/2024/12/8d39-CommitteeofAdjustment-Scarborough-Agenda-January-16-2025.pdf',1,NULL,NULL,'2025-05-02 07:40:16','2025-05-02 07:40:16'),
(2,'2025-02-12-scarborough','February 12, 2025','2025-02-12','City of Toronto','Scarborough',NULL,NULL,'https://www.toronto.ca/wp-content/uploads/2025/01/86d2-CommitteeofAdjustment-Scarborough-Agenda-February-12-2025.pdf',1,NULL,NULL,'2025-05-02 07:40:16','2025-05-02 07:40:16'),
(3,'2025-03-12-scarborough','March 12, 2025','2025-03-12','City of Toronto','Scarborough',NULL,NULL,'https://www.toronto.ca/wp-content/uploads/2025/02/937e-CommitteeofAdjustment-Scarborough-Hearing-Agenda-March-12-2025.pdf',1,NULL,NULL,'2025-05-02 07:40:16','2025-05-02 07:40:16'),
(4,'2025-04-09-scarborough','April 9, 2025','2025-04-09','City of Toronto','Scarborough',NULL,NULL,'https://www.toronto.ca/wp-content/uploads/2025/03/8d41-CommitteeofAdjustment-Scarborough-Hearing-Agenda-April-9-2025.pdf',1,NULL,NULL,'2025-05-02 07:40:16','2025-05-02 07:40:16'),
(5,'2025-05-07-scarborough','May 7, 2025','2025-05-07','City of Toronto','Scarborough',NULL,NULL,'https://www.toronto.ca/wp-content/uploads/2025/04/97b9-CommitteeofAdjustment-Scarborough-Hearing-Agenda-May-7-2025.pdf',1,NULL,NULL,'2025-05-02 07:40:16','2025-05-02 07:40:16'),
(6,'2024-01-17-scarborough','January 17, 2024','2024-01-17','City of Toronto','Scarborough',NULL,NULL,'https://www.toronto.ca/wp-content/uploads/2023/12/9300-CommitteeofAdjustment-Scarborough-Agenda-January-17-2024.pdf',1,NULL,NULL,'2025-05-02 07:40:16','2025-05-02 07:40:16'),
(7,'2024-02-14-scarborough','February 14, 2024','2024-02-14','City of Toronto','Scarborough',NULL,NULL,'https://www.toronto.ca/wp-content/uploads/2024/01/972f-CommitteeofAdjustment-Scarborough-Hearing-Agenda-February-14-2024.pdf',1,NULL,NULL,'2025-05-02 07:40:16','2025-05-02 07:40:16'),
(8,'2024-03-06-scarborough','March 6, 2024','2024-03-06','City of Toronto','Scarborough',NULL,NULL,'https://www.toronto.ca/wp-content/uploads/2024/02/9335-CommitteeofAdjustment-Scarborough-Hearing-Agenda-March-6-2024.pdf',1,NULL,NULL,'2025-05-02 07:40:16','2025-05-02 07:40:16'),
(9,'2024-04-03-scarborough','April 3, 2024','2024-04-03','City of Toronto','Scarborough',NULL,NULL,'https://www.toronto.ca/wp-content/uploads/2024/03/9512-CommitteeofAdjustment-Scarborough-Hearing-Agenda-April-3-2024.pdf',1,NULL,NULL,'2025-05-02 07:40:16','2025-05-02 07:40:16'),
(10,'2024-05-01-scarborough','May 1, 2024','2024-05-01','City of Toronto','Scarborough',NULL,NULL,'https://www.toronto.ca/wp-content/uploads/2024/04/9572-CommitteeofAdjustment-Scarborough-Hearing-Agenda-May-1-2024.pdf',1,NULL,NULL,'2025-05-02 07:40:16','2025-05-02 07:40:16'),
(11,'2024-06-05-scarborough','June 5, 2024','2024-06-05','City of Toronto','Scarborough',NULL,NULL,'https://www.toronto.ca/wp-content/uploads/2024/05/952b-CommitteeofAdjustment-Scarborough-Hearing-Agenda-June-5-2024.pdf',1,NULL,NULL,'2025-05-02 07:40:16','2025-05-02 07:40:16'),
(12,'2024-06-26-scarborough','June 26, 2024','2024-06-26','City of Toronto','Scarborough',NULL,NULL,'https://www.toronto.ca/wp-content/uploads/2024/06/8eb3-CommitteeofAdjustment-Scarborough-Agenda-June-26-2024.pdf',1,NULL,NULL,'2025-05-02 07:40:16','2025-05-02 07:40:16'),
(13,'2024-07-24-scarborough','July 24, 2024','2024-07-24','City of Toronto','Scarborough',NULL,NULL,'https://www.toronto.ca/wp-content/uploads/2024/07/9794-CommitteeofAdjustment-Scarborough-Hearing-Agenda-July-24-2024.pdf',1,NULL,NULL,'2025-05-02 07:40:16','2025-05-02 07:40:16'),
(14,'2024-08-22-scarborough','August 22, 2024','2024-08-22','City of Toronto','Scarborough',NULL,NULL,'https://www.toronto.ca/wp-content/uploads/2024/07/96c3-CommitteeofAdjustment-Scarborough-Hearing-Agenda-August-22-2024.pdf',1,NULL,NULL,'2025-05-02 07:40:16','2025-05-02 07:40:16'),
(15,'2024-09-18-scarborough','September 18, 2024','2024-09-18','City of Toronto','Scarborough',NULL,NULL,'https://www.toronto.ca/wp-content/uploads/2024/08/973c-CommitteeofAdjustment-Scarborough-Hearing-Agenda-September-18-2024.pdf',1,NULL,NULL,'2025-05-02 07:40:16','2025-05-02 07:40:16'),
(16,'2024-10-16-scarborough','October 16, 2024','2024-10-16','City of Toronto','Scarborough',NULL,NULL,'https://www.toronto.ca/wp-content/uploads/2024/09/90cd-CommitteeofAdjustment-Hearing-Agenda-Scarborough-October-16-2024.pdf',1,NULL,NULL,'2025-05-02 07:40:16','2025-05-02 07:40:16'),
(17,'2024-11-13-scarborough','November 13, 2024','2024-11-13','City of Toronto','Scarborough',NULL,NULL,'https://www.toronto.ca/wp-content/uploads/2024/10/96da-CommitteeofAdjustment-Scarborough-Hearing-Agenda-November-13-2024.pdf',1,NULL,NULL,'2025-05-02 07:40:16','2025-05-02 07:40:16'),
(18,'2024-12-04-scarborough','December 4, 2024','2024-12-04','City of Toronto','Scarborough',NULL,NULL,'https://www.toronto.ca/wp-content/uploads/2024/11/90f0-CommitteeofAdjustment-Scarborough-Hearing-Agenda-December-4-2024.pdf',1,NULL,NULL,'2025-05-02 07:40:16','2025-05-02 07:40:16');
/*!40000 ALTER TABLE `meetings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES
(1,'0001_01_01_000000_create_users_table',1),
(2,'0001_01_01_000001_create_cache_table',1),
(3,'0001_01_01_000002_create_jobs_table',1),
(4,'2025_03_25_191501_create_meetings_table',1),
(5,'2025_03_25_192409_create_locations_table',1),
(6,'2025_03_25_192608_create_meeting_videos_table',1),
(7,'2025_03_25_192629_create_applications_table',1),
(8,'2025_03_25_192656_create_location_video_segments_table',1),
(9,'2025_03_25_192721_create_search_histories_table',1),
(10,'2025_03_26_234604_create_run_commands_table',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_tokens`
--

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `run_commands`
--

DROP TABLE IF EXISTS `run_commands`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `run_commands` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `command` varchar(255) NOT NULL,
  `argument` varchar(255) DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `run_commands`
--

LOCK TABLES `run_commands` WRITE;
/*!40000 ALTER TABLE `run_commands` DISABLE KEYS */;
INSERT INTO `run_commands` VALUES
(1,'Import Data from Scarborough Meeting','meeting:json-migrate','http://192.3.155.50/prg/json_v2/scb_meetings_data.json',0,'2025-05-02 07:40:06','2025-05-02 07:40:06'),
(2,'Import Data from Etobicoke Meeting','meeting:json-migrate','http://192.3.155.50/prg/json_v2/etob_meetings_data.json',0,'2025-05-02 07:40:06','2025-05-02 07:40:06'),
(3,'Import Data from North York Meeting','meeting:json-migrate','http://192.3.155.50/prg/json_v2/ny_meetings_data.json',0,'2025-05-02 07:40:06','2025-05-02 07:40:06'),
(4,'Import Data from Toronto & East York Meeting','meeting:json-migrate','http://192.3.155.50/prg/json_v2/tey_meetings_data.json',0,'2025-05-02 07:40:06','2025-05-02 07:40:06'),
(5,'Import Youtube Data','meeting-video:json-migrate','http://192.3.155.50/prg/json/youtube_video_list.json',0,'2025-05-02 07:40:06','2025-05-02 07:40:06'),
(6,'Clean Up Address','location:clean-address','',0,'2025-05-02 07:40:06','2025-05-02 07:40:06'),
(7,'Update Location Postcode and Address','location:update-details','',0,'2025-05-02 07:40:06','2025-05-02 07:40:06'),
(8,'Remove location data North York','meeting:delete-bulk','North York',0,'2025-05-02 07:40:06','2025-05-02 07:40:06'),
(9,'Remove location data Etobicoke York','meeting:delete-bulk','Etobicoke York',0,'2025-05-02 07:40:06','2025-05-02 07:40:06'),
(10,'Remove location data Scarborough','meeting:delete-bulk','Scarborough',0,'2025-05-02 07:40:06','2025-05-02 07:40:06'),
(11,'Remove location data Toronto & East York','meeting:delete-bulk','Toronto & East York',0,'2025-05-02 07:40:06','2025-05-02 07:40:06'),
(12,'Remove Duplicate Locations','location:clean-duplicate','',0,'2025-05-02 07:40:06','2025-05-02 07:40:06');
/*!40000 ALTER TABLE `run_commands` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `search_histories`
--

DROP TABLE IF EXISTS `search_histories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `search_histories` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `location` text DEFAULT NULL,
  `location_id` bigint(20) unsigned NOT NULL,
  `user` bigint(20) DEFAULT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `search_histories_location_id_foreign` (`location_id`),
  KEY `search_histories_user_id_foreign` (`user_id`),
  CONSTRAINT `search_histories_location_id_foreign` FOREIGN KEY (`location_id`) REFERENCES `locations` (`id`) ON DELETE CASCADE,
  CONSTRAINT `search_histories_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `search_histories`
--

LOCK TABLES `search_histories` WRITE;
/*!40000 ALTER TABLE `search_histories` DISABLE KEYS */;
/*!40000 ALTER TABLE `search_histories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` varchar(255) NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `payload` longtext NOT NULL,
  `last_activity` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES
('3tZEVEiIGlLEGwR9NQLq7j4pAhHoNBWMhXUhJecf',2,'172.18.0.6','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36','YTo2OntzOjY6Il90b2tlbiI7czo0MDoiSnltbU5XamVDUThJd2FsQzRZUjRjTXFuY0xZT0MwbEtmZkFJaEh5RSI7czozOiJ1cmwiO2E6MTp7czo4OiJpbnRlbmRlZCI7czo0NzoiaHR0cHM6Ly9wbGFuZXhhLWRvY3VtZW50LXJlcG8uZGRldi5zaXRlL2JhY2tlbmQiO31zOjk6Il9wcmV2aW91cyI7YToxOntzOjM6InVybCI7czo1NzoiaHR0cHM6Ly9wbGFuZXhhLWRvY3VtZW50LXJlcG8uZGRldi5zaXRlL2JhY2tlbmQvZGFzaGJvYXJkIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czo1MDoibG9naW5fd2ViXzU5YmEzNmFkZGMyYjJmOTQwMTU4MGYwMTRjN2Y1OGVhNGUzMDk4OWQiO2k6MjtzOjg6ImZpbGFtZW50IjthOjE6e3M6MTM6Im5vdGlmaWNhdGlvbnMiO2E6Mjp7aTowO2E6MTE6e3M6MjoiaWQiO3M6MzY6IjllZDUyMTczLTgxZDMtNGRjNi1iNDY2LTNlNzBjNTc1M2ZmZiI7czo3OiJhY3Rpb25zIjthOjA6e31zOjQ6ImJvZHkiO047czo1OiJjb2xvciI7TjtzOjg6ImR1cmF0aW9uIjtpOjYwMDA7czo0OiJpY29uIjtzOjIzOiJoZXJvaWNvbi1vLWNoZWNrLWNpcmNsZSI7czo5OiJpY29uQ29sb3IiO3M6Nzoic3VjY2VzcyI7czo2OiJzdGF0dXMiO3M6Nzoic3VjY2VzcyI7czo1OiJ0aXRsZSI7czoxNjoiTG9naW4gU3VjY2Vzc2Z1bCI7czo0OiJ2aWV3IjtzOjM2OiJmaWxhbWVudC1ub3RpZmljYXRpb25zOjpub3RpZmljYXRpb24iO3M6ODoidmlld0RhdGEiO2E6MDp7fX1pOjE7YToxMTp7czoyOiJpZCI7czozNjoiOWVkNTJhMjItZDA1Zi00NzNjLTgzOWEtMDQyNjBlMjgwMGM3IjtzOjc6ImFjdGlvbnMiO2E6MDp7fXM6NDoiYm9keSI7TjtzOjU6ImNvbG9yIjtOO3M6ODoiZHVyYXRpb24iO2k6NjAwMDtzOjQ6Imljb24iO3M6MjM6Imhlcm9pY29uLW8tY2hlY2stY2lyY2xlIjtzOjk6Imljb25Db2xvciI7czo3OiJzdWNjZXNzIjtzOjY6InN0YXR1cyI7czo3OiJzdWNjZXNzIjtzOjU6InRpdGxlIjtzOjE2OiJMb2dpbiBTdWNjZXNzZnVsIjtzOjQ6InZpZXciO3M6MzY6ImZpbGFtZW50LW5vdGlmaWNhdGlvbnM6Om5vdGlmaWNhdGlvbiI7czo4OiJ2aWV3RGF0YSI7YTowOnt9fX19fQ==',1746385614),
('Ep1UMwwIGzShhbZd9tcoEU3ZXXThXJlWNySHiYCw',NULL,'172.18.0.6','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.4 Safari/605.1.15','YTozOntzOjY6Il90b2tlbiI7czo0MDoiT3pnR0I3aUJLcXoxQTlxaW44bk5HMUNNNHV6NVU5ZVFva0pjR2ltMyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6OTQ6Imh0dHBzOi8vcGxhbmV4YS1kb2N1bWVudC1yZXBvLmRkZXYuc2l0ZS9zZWFyY2gtbG9jYXRpb25zP2xhdD00My42NTMyMjUmbG5nPS03OS4zODMxODYmcmFkaXVzPTEiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',1746384254);
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(255) NOT NULL DEFAULT 'customer',
  `remember_token` varchar(100) DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES
(1,'seeder','seed@mail.com','2025-05-02 07:40:05','$2y$12$NNsBOTHG5KKTMPUNlq.qF.sxAOPaSMNLBBFhqSiTrKPLsHMXdoUq.','seeder',NULL,NULL,'2025-05-02 07:40:05','2025-05-02 07:40:05'),
(2,'admin','admin@mail.com','2025-05-02 07:40:05','$2y$12$sjlGfuVs4xyTE88rmFuY6.j25WftBNA4WurblemFW2X8HuU58.qLi','admin',NULL,NULL,'2025-05-02 07:40:05','2025-05-02 07:40:05'),
(3,'Cynthia','Cynthiachineme@gmail.com','2025-05-02 07:40:05','$2y$12$4GnczgRJusafGxzcpBlBSuz01MbjK6YGwpHjW.8I9fKTvOcOVc/dq','admin',NULL,NULL,'2025-05-02 07:40:05','2025-05-02 07:40:05'),
(4,'Hiruni','hirunimalsha789@gmail.com','2025-05-02 07:40:05','$2y$12$LWKed8WmCbBnJUBjrB0Gge1Lt8jXguIVaqh.3MMRdPu/NpjRz1h5S','admin',NULL,NULL,'2025-05-02 07:40:05','2025-05-02 07:40:05'),
(5,'Sampavi','sampavi.shanthakumar@gmail.com','2025-05-02 07:40:05','$2y$12$TCoEDgSkuvzC57aayb7EYegUazQZBN9hskn3SMulMiG7H5G2yJqOm','admin',NULL,NULL,'2025-05-02 07:40:05','2025-05-02 07:40:05'),
(6,'Vanessa','kudos2vannycan@gmail.com','2025-05-02 07:40:05','$2y$12$yWo/drNXHXa9MN6fqRoMoOY5TLLD4ytN3Qh./nLhDXBpLDaTXmOe.','admin',NULL,NULL,'2025-05-02 07:40:05','2025-05-02 07:40:05'),
(7,'lava','kirus.lava@gmail.com','2025-05-02 07:40:06','$2y$12$gkeswV1zX4tLjKYxYaXmyeT7KL.HsvyOCIL.6yz2cXUQMQ5dCSj6i','admin',NULL,NULL,'2025-05-02 07:40:06','2025-05-02 07:40:06');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-05-04 15:09:27
